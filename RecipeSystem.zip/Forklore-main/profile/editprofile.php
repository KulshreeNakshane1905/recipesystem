<?php
// Start session to access user data
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if not logged in
    header("Location: ../landingpage/landingpage.html");
    exit();
}

// Database connection
$host = 'localhost';
$dbname = 'forklore';
$username = 'root';
$password = '';

$message = '';
$error = '';

try {
    // Create database connection
    $conn = new mysqli($host, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
        throw new Exception("Database connection failed: " . $conn->connect_error);
    }
    
    // Get user data
    $userId = $_SESSION['user_id'];
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        throw new Exception("User not found");
    }
    
    $user = $result->fetch_assoc();
    
    // Process form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Collect form data
        $firstName = trim($_POST['first_name']);
        $lastName = trim($_POST['last_name']);
        $email = trim($_POST['email']);
        $phone = trim($_POST['phone']);
        $location = trim($_POST['location']);
        $bio = trim($_POST['bio']);
        
        // Validate email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Invalid email format";
        } else {
            // Check if email already exists for another user
            $emailStmt = $conn->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
            $emailStmt->bind_param("si", $email, $userId);
            $emailStmt->execute();
            $emailResult = $emailStmt->get_result();
            
            if ($emailResult->num_rows > 0) {
                $error = "Email already in use by another account";
            } else {
                // Update user profile
                $updateStmt = $conn->prepare("UPDATE users SET first_name = ?, last_name = ?, email = ?, phone = ?, location = ?, bio = ? WHERE id = ?");
                $updateStmt->bind_param("ssssssi", $firstName, $lastName, $email, $phone, $location, $bio, $userId);
                
                if ($updateStmt->execute()) {
                    $message = "Profile updated successfully!";
                    
                    // Refresh user data
                    $stmt->execute();
                    $result = $stmt->get_result();
                    $user = $result->fetch_assoc();
                } else {
                    $error = "Error updating profile: " . $conn->error;
                }
            }
        }
        
        // Handle dietary preferences if the table exists
        if (isset($_POST['preferences']) && is_array($_POST['preferences']) && $conn->query("SHOW TABLES LIKE 'user_preferences'")->num_rows > 0) {
            // Remove existing preferences
            $deletePrefs = $conn->prepare("DELETE FROM user_preferences WHERE user_id = ?");
            $deletePrefs->bind_param("i", $userId);
            $deletePrefs->execute();
            
            // Add new preferences
            $addPrefStmt = $conn->prepare("INSERT INTO user_preferences (user_id, preference_name) VALUES (?, ?)");
            foreach ($_POST['preferences'] as $preference) {
                $preference = trim($preference);
                if (!empty($preference)) {
                    $addPrefStmt->bind_param("is", $userId, $preference);
                    $addPrefStmt->execute();
                }
            }
        }
    }
    
    // Get user's dietary preferences
    $preferences = [];
    if ($conn->query("SHOW TABLES LIKE 'user_preferences'")->num_rows > 0) {
        $prefStmt = $conn->prepare("SELECT preference_name FROM user_preferences WHERE user_id = ?");
        $prefStmt->bind_param("i", $userId);
        $prefStmt->execute();
        $prefResult = $prefStmt->get_result();
        
        while ($row = $prefResult->fetch_assoc()) {
            $preferences[] = $row['preference_name'];
        }
    }
    
    // Close connection
    $conn->close();
    
} catch (Exception $e) {
    $error = $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TastyBytes - Edit Profile</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        
        :root {
            --primary-color: #ff6b6b;
            --secondary-color: #4ecdc4;
            --accent-color: #ffd166;
            --dark-color: #2d3436;
            --light-color: #f9f9f9;
            --veg-color: #4ecdc4;
            --nonveg-color: #ff6b6b;
            --vegan-color: #6bbd99;
            --all-color: #ffd166;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--light-color);
            color: var(--dark-color);
            min-height: 100vh;
        }
        
        .header {
            background-color: white;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo {
            font-size: 1.8rem;
            font-weight: 700;
            background: linear-gradient(45deg, var(--veg-color), var(--nonveg-color), var(--vegan-color));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        
        .nav-links {
            display: flex;
            gap: 2rem;
        }
        
        .nav-link {
            color: var(--dark-color);
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s;
        }
        
        .nav-link:hover {
            color: var(--primary-color);
        }
        
        .main-container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 2rem;
            background-color: white;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        .form-title {
            font-size: 1.8rem;
            margin-bottom: 1.5rem;
            text-align: center;
            color: var(--dark-color);
        }
        
        .form-section {
            margin-bottom: 1.5rem;
        }
        
        .form-group {
            margin-bottom: 1rem;
        }
        
        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
        }
        
        input[type="text"],
        input[type="email"],
        input[type="tel"],
        textarea {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-family: 'Poppins', sans-serif;
        }
        
        .checkbox-group {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
            margin-top: 0.5rem;
        }
        
        .checkbox-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .checkbox-item input[type="checkbox"] {
            accent-color: var(--secondary-color);
        }
        
        .alert {
            padding: 1rem;
            margin-bottom: 1rem;
            border-radius: 8px;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .btn-container {
            display: flex;
            gap: 1rem;
            margin-top: 2rem;
        }
        
        .btn {
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            border: none;
            font-weight: 500;
            cursor: pointer;
            font-family: 'Poppins', sans-serif;
            transition: all 0.3s;
        }
        
        .btn-primary {
            background-color: var(--secondary-color);
            color: white;
        }
        
        .btn-outline {
            background-color: transparent;
            border: 1px solid var(--secondary-color);
            color: var(--secondary-color);
        }
        
        .btn:hover {
            opacity: 0.9;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="logo">TastyBytes</div>
        <nav class="nav-links">
            <a href="../choicepage/choice.html" class="nav-link">Home</a>
            <a href="#" class="nav-link">Recipes</a>
            <a href="#" class="nav-link">Favorites</a>
            <a href="profile.php" class="nav-link">Profile</a>
        </nav>
    </header>
    
    <div class="main-container">
        <h1 class="form-title">Edit Your Profile</h1>
        
        <?php if (!empty($message)): ?>
            <div class="alert alert-success">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-section">
                <h2>Personal Information</h2>
                
                <div class="form-group">
                    <label for="first_name">First Name</label>
                    <input type="text" id="first_name" name="first_name" value="<?php echo htmlspecialchars($user['first_name'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="last_name">Last Name</label>
                    <input type="text" id="last_name" name="last_name" value="<?php echo htmlspecialchars($user['last_name'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="phone">Phone Number (optional)</label>
                    <input type="tel" id="phone" name="phone" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="location">Location (optional)</label>
                    <input type="text" id="location" name="location" value="<?php echo htmlspecialchars($user['location'] ?? ''); ?>">
                </div>