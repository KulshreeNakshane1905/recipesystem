<?php
// Start session to access user data
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if not logged in
    header("Location: ../landingpage/landingpage.html");
    exit();
}

// Database connection
$host = 'localhost';
$dbname = 'forklore';
$username = 'root';
$password = '';

try {
    // Create database connection
    $conn = new mysqli($host, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
        throw new Exception("Database connection failed: " . $conn->connect_error);
    }
    
    // Get user data
    $userId = $_SESSION['user_id'];
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        throw new Exception("User not found");
    }
    
    $user = $result->fetch_assoc();
    
    // Get user's favorites count
    $favStmt = $conn->prepare("SELECT COUNT(*) as favorite_count FROM recipe_favorites WHERE user_id = ?");
    $favStmt->bind_param("i", $userId);
    $favStmt->execute();
    $favResult = $favStmt->get_result();
    $favCount = $favResult->fetch_assoc()['favorite_count'];
    
    // Get user's created recipes count
    $recipeStmt = $conn->prepare("SELECT COUNT(*) as recipe_count FROM recipes WHERE user_id = ?");
    $recipeStmt->bind_param("i", $userId);
    $recipeStmt->execute();
    $recipeResult = $recipeStmt->get_result();
    $recipeCount = $recipeResult->fetch_assoc()['recipe_count'];
    
    // Get user's tried recipes count (assuming we have a table tracking this)
    $triedCount = 0; // Default value
    if ($conn->query("SHOW TABLES LIKE 'recipe_tried'")->num_rows > 0) {
        $triedStmt = $conn->prepare("SELECT COUNT(*) as tried_count FROM recipe_tried WHERE user_id = ?");
        $triedStmt->bind_param("i", $userId);
        $triedStmt->execute();
        $triedResult = $triedStmt->get_result();
        $triedCount = $triedResult->fetch_assoc()['tried_count'];
    }
    
    // Get user's dietary preferences (assuming we have a table for this)
    $preferences = [];
    if ($conn->query("SHOW TABLES LIKE 'user_preferences'")->num_rows > 0) {
        $prefStmt = $conn->prepare("SELECT preference_name FROM user_preferences WHERE user_id = ?");
        $prefStmt->bind_param("i", $userId);
        $prefStmt->execute();
        $prefResult = $prefStmt->get_result();
        
        while ($row = $prefResult->fetch_assoc()) {
            $preferences[] = $row['preference_name'];
        }
    }
    
    // Close connection
    $conn->close();
    
} catch (Exception $e) {
    $error = $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TastyBytes - User Profile</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        
        :root {
            --primary-color: #ff6b6b;
            --secondary-color: #4ecdc4;
            --accent-color: #ffd166;
            --dark-color: #2d3436;
            --light-color: #f9f9f9;
            --veg-color: #4ecdc4;
            --nonveg-color: #ff6b6b;
            --vegan-color: #6bbd99;
            --all-color: #ffd166;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--light-color);
            color: var(--dark-color);
            min-height: 100vh;
        }
        
        .header {
            background-color: white;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo {
            font-size: 1.8rem;
            font-weight: 700;
            background: linear-gradient(45deg, var(--veg-color), var(--nonveg-color), var(--vegan-color));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        
        .nav-links {
            display: flex;
            gap: 2rem;
        }
        
        .nav-link {
            color: var(--dark-color);
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s;
        }
        
        .nav-link:hover {
            color: var(--primary-color);
        }
        
        .main-container {
            max-width: 1000px;
            margin: 2rem auto;
            padding: 2rem;
            background-color: white;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        .profile-header {
            display: flex;
            align-items: center;
            gap: 2rem;
            margin-bottom: 2rem;
            padding-bottom: 2rem;
            border-bottom: 1px solid #eee;
        }
        
        .avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background: linear-gradient(45deg, var(--veg-color), var(--nonveg-color));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 3rem;
        }
        
        .profile-info h1 {
            margin-bottom: 0.5rem;
        }
        
        .profile-info p {
            color: #777;
        }
        
        .profile-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background-color: #f8f8f8;
            border-radius: 15px;
            padding: 1.5rem;
            text-align: center;
            transition: all 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.05);
        }
        
        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            color: var(--secondary-color);
        }
        
        .stat-label {
            color: #777;
            font-size: 0.9rem;
        }
        
        .profile-sections {
            display: grid;
            grid-template-columns: 1fr;
            gap: 2rem;
        }
        
        .section-title {
            font-size: 1.5rem;
            margin-bottom: 1rem;
            position: relative;
            padding-bottom: 0.5rem;
        }
        
        .section-title::after {
            content: "";
            position: absolute;
            bottom: 0;
            left: 0;
            width: 50px;
            height: 3px;
            background: linear-gradient(to right, var(--veg-color), var(--nonveg-color));
            border-radius: 10px;
        }
        
        .preferences {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            margin-bottom: 2rem;
        }
        
        .preference-tag {
            background-color: #f0f0f0;
            padding: 0.5rem 1rem;
            border-radius: 50px;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .preference-tag i {
            color: var(--secondary-color);
        }
        
        .action-buttons {
            display: flex;
            gap: 1rem;
            margin-top: 2rem;
        }
        
        .btn {
            background: linear-gradient(45deg, var(--veg-color), var(--nonveg-color));
            color: white;
            border: none;
            padding: 0.8rem 2rem;
            border-radius: 50px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }
        
        .btn-outline {
            background: transparent;
            border: 2px solid var(--secondary-color);
            color: var(--secondary-color);
        }
        
        .btn-outline:hover {
            background-color: rgba(78, 205, 196, 0.1);
        }
        
        @media (max-width: 768px) {
            .profile-header {
                flex-direction: column;
                text-align: center;
                gap: 1rem;
            }
            
            .nav-links {
                gap: 1rem;
            }
            
            .main-container {
                padding: 1.5rem;
                margin: 1rem;
            }
            
            .action-buttons {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="logo">TastyBytes</div>
        <nav class="nav-links">
            <a href="../choicepage/choice.html" class="nav-link">Home</a>
            <a href="#" class="nav-link">Recipes</a>
            <a href="#" class="nav-link">Favorites</a>
            <a href="logout.php" class="nav-link">Logout</a>
        </nav>
    </header>
    
    <?php if (isset($error)): ?>
    <div style="background-color: #f8d7da; color: #721c24; padding: 1rem; margin: 2rem auto; max-width: 1000px; border-radius: 10px; text-align: center;">
        <p>Error: <?php echo $error; ?></p>
        <p>Please <a href="../landingpage/landingpage.html" style="color: #721c24; text-decoration: underline;">log in</a> again.</p>
    </div>
    <?php else: ?>
    
    <div class="main-container">
        <div class="profile-header">
            <div class="avatar"><?php echo strtoupper(substr($user['username'] ?? $user['first_name'] ?? 'U', 0, 1)); ?></div>
            <div class="profile-info">
                <h1><?php echo htmlspecialchars($user['username'] ?? ($user['first_name'] ? $user['first_name'] . ' ' . $user['last_name'] : 'User')); ?></h1>
                <p>Member since <?php echo date('F j, Y', strtotime($user['created_at'])); ?></p>
            </div>
        </div>
        
        <div class="profile-stats">
            <div class="stat-card">
                <div class="stat-number"><?php echo $favCount; ?></div>
                <div class="stat-label">Favorite Recipes</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $recipeCount; ?></div>
                <div class="stat-label">Recipes Created</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $triedCount; ?></div>
                <div class="stat-label">Recipes Tried</div>
            </div>
        </div>
        
        <div class="profile-sections">
            <div>
                <h2 class="section-title">Dietary Preferences</h2>
                <div class="preferences">
                    <?php if (empty($preferences)): ?>
                        <p>No dietary preferences set yet.</p>
                    <?php else: ?>
                        <?php foreach ($preferences as $preference): ?>
                            <div class="preference-tag">
                                <i class="fas fa-<?php 
                                    // Choose icon based on preference
                                    if (stripos($preference, 'vegan') !== false) {
                                        echo 'seedling';
                                    } elseif (stripos($preference, 'vegetarian') !== false) {
                                        echo 'leaf';
                                    } elseif (stripos($preference, 'carb') !== false) {
                                        echo 'utensils';
                                    } elseif (stripos($preference, 'spicy') !== false) {
                                        echo 'pepper-hot';
                                    } elseif (stripos($preference, 'gluten') !== false) {
                                        echo 'wheat-awn';
                                    } else {
                                        echo 'check-circle';
                                    }
                                ?>"></i>
                                <span><?php echo htmlspecialchars($preference); ?></span>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            
            <div>
                <h2 class="section-title">Account Details</h2>
                <div style="margin-bottom: 1.5rem;">
                    <p style="margin: 0.5rem 0; display: flex; justify-content: space-between;">
                        <span style="color: #777;">Email:</span>
                        <span style="font-weight: 500;"><?php echo htmlspecialchars($user['email']); ?></span>
                    </p>
                    <p style="margin: 0.5rem 0; display: flex; justify-content: space-between;">
                        <span style="color: #777;">Phone:</span>
                        <span style="font-weight: 500;"><?php echo !empty($user['phone']) ? htmlspecialchars($user['phone']) : 'Not provided'; ?></span>
                    </p>
                    <p style="margin: 0.5rem 0; display: flex; justify-content: space-between;">
                        <span style="color: #777;">Location:</span>
                        <span style="font-weight: 500;"><?php echo !empty($user['location']) ? htmlspecialchars($user['location']) : 'Not provided'; ?></span>
                    </p>
                </div>
            </div>
        </div>
        
        <div class="action-buttons">
            <button class="btn" onclick="window.location.href='edit_profile.php'">
                <i class="fas fa-pencil-alt"></i>
                <span>Edit Profile</span>
            </button>
            <button class="btn btn-outline" onclick="window.location.href='change_password.php'">
                <i class="fas fa-key"></i>
                <span>Change Password</span>
            </button>
        </div>
    </div>
    <?php endif; ?>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Handle button clicks to navigate to appropriate pages
            document.querySelectorAll('.btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    const action = this.textContent.trim();
                    if (action === 'Edit Profile') {
                        window.location.href = 'edit_profile.php';
                    } else if (action === 'Change Password') {
                        window.location.href = 'change_password.php';
                    }
                });
            });
        });
    </script>
</body>
</html>
<?php endif; ?>