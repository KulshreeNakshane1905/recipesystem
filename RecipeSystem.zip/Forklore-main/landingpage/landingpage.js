document.addEventListener('DOMContentLoaded', () => {
    // Initialize ScrollMagic controller
    let controller = new ScrollMagic.Controller();
    
    // Add loading animation
    const body = document.querySelector('body');
    body.classList.add('loading');
    
    // Remove loading class after content loads
    window.addEventListener('load', () => {
        setTimeout(() => {
            body.classList.remove('loading');
            gsap.to('.loader', 0.8, {
                opacity: 0,
                display: 'none'
            });
        }, 800);
    });
    
    // Create loader if it doesn't exist
    if (!document.querySelector('.loader')) {
        const loader = document.createElement('div');
        loader.className = 'loader';
        loader.innerHTML = `
            <div class="spinner">
                <div class="bounce1"></div>
                <div class="bounce2"></div>
                <div class="bounce3"></div>
            </div>
        `;
        document.body.prepend(loader);
        
        // Add loader styles
        const loaderStyle = document.createElement('style');
        loaderStyle.textContent = `
            body.loading {
                overflow: hidden;
            }
            .loader {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background-color: #fff;
                display: flex;
                justify-content: center;
                align-items: center;
                z-index: 9999;
            }
            .spinner {
                width: 70px;
                text-align: center;
            }
            .spinner > div {
                width: 18px;
                height: 18px;
                background-color: #35654d;
                border-radius: 100%;
                display: inline-block;
                animation: bounce 1.4s infinite ease-in-out both;
            }
            .spinner .bounce1 {
                animation-delay: -0.32s;
            }
            .spinner .bounce2 {
                animation-delay: -0.16s;
            }
            @keyframes bounce {
                0%, 80%, 100% { 
                    transform: scale(0);
                } 40% { 
                    transform: scale(1.0);
                }
            }
        `;
        document.head.appendChild(loaderStyle);
    }
    
    // Add scroll progress indicator
    if (!document.querySelector('.scroll-progress')) {
        const progressBar = document.createElement('div');
        progressBar.className = 'scroll-progress';
        document.body.appendChild(progressBar);
        
        // Add progress bar styles
        const progressStyle = document.createElement('style');
        progressStyle.textContent = `
            .scroll-progress {
                position: fixed;
                top: 0;
                left: 0;
                height: 4px;
                background-color: #35654d;
                width: 0%;
                z-index: 9999;
                transition: width 0.1s ease;
            }
        `;
        document.head.appendChild(progressStyle);
        
        // Update progress bar on scroll
        window.addEventListener('scroll', () => {
            const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
            const scrollHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
            const scrolled = (scrollTop / scrollHeight) * 100;
            progressBar.style.width = scrolled + '%';
        });
    }
    
    // First section animations with enhanced effects
    let t1 = gsap.timeline();
    
    // Stagger the ingredient animations for more dynamic effect
    t1.from(".section_1_01", 4, {
            y: -100,
            x: -150,
            rotation: -5,
            ease: Power3.easeInOut
        })
        .from(".section_1_02", 4, {
            y: -150,
            x: -250,
            rotation: 8,
            ease: Power3.easeInOut
        }, '-=3.7')
        .from(".section_1_03", 4, {
            y: -80,
            x: -100,
            rotation: -3,
            ease: Power3.easeInOut
        }, '-=3.5')
        .from(".section_1_04", 4, {
            y: -100,
            x: -150,
            rotation: 6,
            ease: Power3.easeInOut
        }, '-=3.3')
        .from(".section_1_05", 4, {
            y: -80,
            x: -200,
            rotation: -7,
            ease: Power3.easeInOut
        }, '-=3.1')
        .from(".section_1_06", 4, {
            y: -100,
            x: -350,
            rotation: 4,
            ease: Power3.easeInOut
        }, '-=2.9')
        .from(".section_1_07", 4, {
            y: -50,
            x: -150,
            rotation: -5,
            ease: Power3.easeInOut
        }, '-=2.7')
        .from(".section_1_08", 4, {
            y: 50,
            x: -350,
            rotation: 7,
            ease: Power3.easeInOut
        }, '-=2.5')
        .from(".section_1_09", 4, {
            y: 100,
            x: -200,
            rotation: -6,
            ease: Power3.easeInOut
        }, '-=2.3');
    
    // Add parallax effect to background
    gsap.to(".section_1_bg", {
        y: '-20%',
        ease: "none",
        scrollTrigger: {
            trigger: ".first-section",
            start: "top top",
            end: "bottom top",
            scrub: true
        }
    });
    
    let scene = new ScrollMagic.Scene({
            triggerElement: '.first-section',
            duration: '100%',
            triggerHook: 0,
            offset: '300'
        })
        .setTween(t1)
        .setPin('.first-section')
        .addTo(controller);
    
    // Third section animations with enhanced parallax
    let t3 = gsap.timeline();
    t3
        .to('.section_3_01', 4, {
            y: -250,
            rotation: -3,
            ease: Power3.easeInOut
        })
        .to('.section_3_02', 4, {
            y: -200,
            rotation: 2,
            ease: Power3.easeInOut
        }, '-=3.8')
        .to('.section_3_03', 4, {
            y: -100,
            rotation: -1,
            ease: Power3.easeInOut
        }, '-=3.6')
        .to('.section_3_04', 4, {
            y: 0,
            rotation: 1,
            ease: Power3.easeInOut
        }, '-=3.4')
        .to('.section_3_05', 4, {
            y: 150,
            rotation: -2,
            ease: Power3.easeInOut
        }, '-=3.2')
        .to('.section_3_06', 4, {
            y: 250,
            rotation: 3,
            ease: Power3.easeInOut
        }, '-=3');
    
    let scene3 = new ScrollMagic.Scene({
            triggerElement: '.third-section',
            duration: '100%',
            triggerHook: 0,
            offset: '200'
        })
        .setTween(t3)
        .setPin('.third-section')
        .addTo(controller);
    
    // Fourth section animations with enhanced transitions
    let t4 = gsap.timeline();
    t4
        .to('.section_4_01', 4, {
            autoAlpha: 0,
            scale: 0.8,
            rotation: -5
        })
        .from('.section_4_02', 4, {
            autoAlpha: 0,
            scale: 1.2,
            rotation: 5
        }, '-=3.5')
        .from('.section_4_03', 4, {
            autoAlpha: 0,
            scale: 0.9,
            rotation: -3
        }, '-=1.5')
        .from('.section_4_04', 4, {
            autoAlpha: 0,
            scale: 1.1,
            rotation: 3
        }, '-=1.5');
    
    let scene4 = new ScrollMagic.Scene({
            triggerElement: '.forth-section',
            duration: '100%',
            triggerHook: 0,
            offset: '200'
        })
        .setTween(t4)
        .setPin('.forth-section')
        .addTo(controller);
    
    // Add reveal animations for text elements
    gsap.utils.toArray('h1, h2').forEach(heading => {
        gsap.from(heading, {
            y: 50,
            opacity: 0,
            duration: 1,
            ease: "power3.out",
            scrollTrigger: {
                trigger: heading,
                start: "top 80%",
                toggleActions: "play none none none"
            }
        });
    });
    
    // Add hover effects for interactive elements
    const addHoverEffects = () => {
        // Add hover effects to navigation links
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('mouseenter', () => {
                gsap.to(link, 0.3, {
                    y: -3,
                    color: '#35654d',
                    ease: Power2.easeOut
                });
            });
            
            link.addEventListener('mouseleave', () => {
                gsap.to(link, 0.3, {
                    y: 0,
                    color: '',
                    ease: Power2.easeOut
                });
            });
        });
        
        // Add hover effect to buttons
        const buttons = document.querySelectorAll('.button');
        buttons.forEach(button => {
            button.addEventListener('mouseenter', () => {
                gsap.to(button, 0.3, {
                    scale: 1.05,
                    ease: Power2.easeOut
                });
            });
            
            button.addEventListener('mouseleave', () => {
                gsap.to(button, 0.3, {
                    scale: 1,
                    ease: Power2.easeOut
                });
            });
        });
    };
    
    addHoverEffects();
    
    // Hamburger menu functionality
    if (!document.querySelector('.hamburger')) {
        const header = document.querySelector('header');
        const hamburgerBtn = document.createElement('div');
        hamburgerBtn.className = 'hamburger';
        hamburgerBtn.innerHTML = `
            <span></span>
            <span></span>
            <span></span>
        `;
        header.appendChild(hamburgerBtn);
        
        // Add hamburger menu styles with animated transitions
        const style = document.createElement('style');
        style.textContent = `
            .hamburger {
                display: none;
                flex-direction: column;
                justify-content: space-between;
                width: 30px;
                height: 21px;
                cursor: pointer;
                z-index: 100;
            }
            
            .hamburger span {
                display: block;
                height: 3px;
                width: 100%;
                background-color: #35654d;
                transition: all 0.3s ease;
            }
            
            .hamburger.active span:nth-child(1) {
                transform: translateY(9px) rotate(45deg);
            }
            
            .hamburger.active span:nth-child(2) {
                opacity: 0;
            }
            
            .hamburger.active span:nth-child(3) {
                transform: translateY(-9px) rotate(-45deg);
            }
            
            @media (max-width: 768px) {
                .hamburger {
                    display: flex;
                }
                
                .nav-all {
                    position: fixed;
                    top: 0;
                    right: -100%;
                    width: 250px;
                    height: 100vh;
                    background-color: white;
                    padding: 80px 20px 20px;
                    transition: right 0.3s ease;
                    box-shadow: -5px 0 15px rgba(0,0,0,0.1);
                    z-index: 90;
                }
                
                .nav-all.open {
                    right: 0;
                }
                
                .nav-1, .nav-2 {
                    flex-direction: column;
                    align-items: flex-start;
                }
                
                .nav-link, .button {
                    margin: 10px 0;
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    // Set up hamburger menu toggle with animation
    const hamburger = document.querySelector('.hamburger');
    const navAll = document.querySelector('.nav-all');
    
    if (hamburger) {
        hamburger.addEventListener('click', () => {
            navAll.classList.toggle('open');
            hamburger.classList.toggle('active');
            
            // Animate menu items when opening
            if (navAll.classList.contains('open')) {
                const navItems = navAll.querySelectorAll('.nav-link, .button');
                gsap.from(navItems, {
                    y: 20,
                    opacity: 0,
                    stagger: 0.1,
                    duration: 0.4,
                    ease: "power2.out",
                    delay: 0.2
                });
            }
        });
    }
    
    // Add smooth scrolling for navigation links
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            const href = link.getAttribute('href');
            
            // Only apply smooth scroll to page anchors, not external links
            if (href && href.startsWith('#') && href.length > 1) {
                e.preventDefault();
                
                const targetElement = document.querySelector(href);
                if (targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop,
                        behavior: 'smooth'
                    });
                    
                    // Close mobile menu if open
                    if (navAll.classList.contains('open')) {
                        navAll.classList.remove('open');
                        hamburger.classList.remove('active');
                    }
                }
            }
        });
    });
    
    // Add touch swipe navigation for mobile
    let touchStartX = 0;
    let touchEndX = 0;
    
    document.addEventListener('touchstart', e => {
        touchStartX = e.changedTouches[0].screenX;
    }, false);
    
    document.addEventListener('touchend', e => {
        touchEndX = e.changedTouches[0].screenX;
        handleSwipe();
    }, false);
    
    function handleSwipe() {
        const swipeThreshold = 100;
        
        // Right swipe (open menu)
        if (touchEndX - touchStartX > swipeThreshold && !navAll.classList.contains('open')) {
            navAll.classList.add('open');
            hamburger.classList.add('active');
            
            const navItems = navAll.querySelectorAll('.nav-link, .button');
            gsap.from(navItems, {
                y: 20,
                opacity: 0,
                stagger: 0.1,
                duration: 0.4,
                ease: "power2.out",
                delay: 0.2
            });
        }
        
        // Left swipe (close menu)
        if (touchStartX - touchEndX > swipeThreshold && navAll.classList.contains('open')) {
            navAll.classList.remove('open');
            hamburger.classList.remove('active');
        }
    }
    
    // Add mouse parallax effect to first section
    const firstSection = document.querySelector('.first-section');
    if (firstSection) {
        firstSection.addEventListener('mousemove', (e) => {
            const moveX = (e.clientX - window.innerWidth / 2) / 25;
            const moveY = (e.clientY - window.innerHeight / 2) / 25;
            
            gsap.to('.ingredient-images img', {
                x: moveX,
                y: moveY,
                duration: 1,
                ease: "power1.out",
                stagger: 0.02
            });
        });
    }
    
    // Add scroll-triggered animations for sections
    gsap.registerPlugin(ScrollTrigger);
    
    // Center text animation
    gsap.from('.center-text', {
        scrollTrigger: {
            trigger: '.center-text',
            start: 'top 80%',
            toggleActions: 'play none none none'
        },
        opacity: 0,
        y: 50,
        duration: 1.2,
        ease: "power3.out"
    });
});