document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('userFeedback');
    if (!form) {
        console.error('Form not found!');
        return;
    }
    
    console.log('Form found, attaching listener');
    
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        console.log('Form submitted');

        const submitBtn = this.querySelector('button[type="submit"]');
        const originalBtnText = submitBtn.innerHTML;
        submitBtn.innerHTML = 'Processing...';
        submitBtn.disabled = true;

        const formData = new FormData(this);
        const urlParams = new URLSearchParams();
        for (const pair of formData) {
            urlParams.append(pair[0], pair[1]);
        }

        console.log('Sending fetch request');
        
        fetch('save_feedback.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: urlParams
        })
        .then(response => {
            console.log('Response received', response);
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            console.log('Data received:', data);
            if (data.success) {
                console.log('Success! Redirecting...');
                // Try direct redirection without setTimeout
                window.location.href = '../choicepage/choice.html';
            } else {
                alert('Error: ' + data.message);
                submitBtn.innerHTML = originalBtnText;
                submitBtn.disabled = false;
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while submitting your feedback.');
            submitBtn.innerHTML = originalBtnText;
            submitBtn.disabled = false;
        });
    });
});