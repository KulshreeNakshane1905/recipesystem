<?php
// Database connection details
$host = 'localhost';
$dbname = 'forklore_db';
$username = 'root';
$password = '';

// Create connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => "Connection failed: " . $conn->connect_error]);
    exit;
}

// Collect form data
$name = $_POST['name'];
$email = $_POST['email'];
$feedbackType = $_POST['feedbackType'];
$message = $_POST['message'];
$rating = $_POST['rating'];
$subscribed = isset($_POST['subscribe']) ? 1 : 0;

// Insert into database
$sql = "INSERT INTO feedback (name, email, feedback_type, message, rating, subscribed)
        VALUES (?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssii", $name, $email, $feedbackType, $message, $rating, $subscribed);

header('Content-Type: application/json');
if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Feedback submitted successfully!']);
} else {
    echo json_encode(['success' => false, 'message' => $stmt->error]);
}

$stmt->close();
$conn->close();
?>