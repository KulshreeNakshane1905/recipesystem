<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = ""; // Empty password should use empty string, not space
$dbname = "forklore_db";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>