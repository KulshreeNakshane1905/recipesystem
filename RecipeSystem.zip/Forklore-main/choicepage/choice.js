// Wait for DOM to be fully loaded before attaching event handlers
document.addEventListener('DOMContentLoaded', function() {
    // Generate food icons for background
    generateFoodIcons();
    
    // Add event listeners to radio inputs
    setupRadioInputs();
    
    // Set the first letter of the user's name in the avatar
    const avatar = document.querySelector('.avatar');
    const username = "User"; // Replace with actual username from auth system
    if (avatar) {
        avatar.textContent = username.charAt(0).toUpperCase();
    }
    
    // Setup profile button
    setupProfileButton();
    
    // Setup logout button
    setupLogoutButton();
    
});

// Recipe Cost Calculator button click handler
document.getElementById('costCalculatorBtn').addEventListener('click', function() {
    // Add transition effect before redirecting
    document.body.style.opacity = '0';
    document.body.style.transition = 'opacity 0.5s ease';
    
    setTimeout(() => {
        window.location.href = '../recipecost.html';
    }, 500);
});
// Generate food icons for background
function generateFoodIcons() {
    const foodBg = document.getElementById('foodBg');
    if (!foodBg) return;
    
    const icons = ['🍕', '🍔', '🍟', '🌮', '🍣', '🍜', '🍛', '🍲', '🥗', '🍱', '🥘', '🍝', '🥪', '🌯', '🥙', '🍦', '🍩', '🧁', '🍰', '🍪'];
    const numIcons = 30;
    
    for (let i = 0; i < numIcons; i++) {
        const icon = document.createElement('div');
        icon.className = 'food-icon';
        icon.textContent = icons[Math.floor(Math.random() * icons.length)];
        
        // Random positioning
        icon.style.left = `${Math.random() * 100}%`;
        icon.style.top = `${Math.random() * 100}%`;
        
        // Random animation duration and delay
        const duration = 15 + Math.random() * 30;
        const delay = Math.random() * 15;
        icon.style.animationDuration = `${duration}s`;
        icon.style.animationDelay = `${delay}s`;
        
        foodBg.appendChild(icon);
    }
}

function setupRadioInputs() {
    const radioInputs = document.querySelectorAll('input[type="radio"]');
    const nextBtn = document.getElementById('nextBtn');
    
    if (!nextBtn) return;
    
    radioInputs.forEach(input => {
        input.addEventListener('change', function() {
            // Update button color based on selection
            if (this.value === 'veg') {
                nextBtn.style.background = 'linear-gradient(45deg, var(--veg-color), var(--veg-color))';
            } else if (this.value === 'nonveg') {
                nextBtn.style.background = 'linear-gradient(45deg, var(--nonveg-color), var(--nonveg-color))';
            } else if (this.value === 'vegan') {
                nextBtn.style.background = 'linear-gradient(45deg, var(--vegan-color), var(--vegan-color))';
            } else if (this.value === 'all') {
                nextBtn.style.background = 'linear-gradient(45deg, var(--all-color), var(--all-color))';
            }
        });
    });
    
    // Handle next button click
    nextBtn.addEventListener('click', function() {
        const selectedOption = document.querySelector('input[name="cuisine"]:checked');
        
        if (selectedOption) {
            let url = '';
            switch (selectedOption.value) {
                case 'veg':
                    url = '../veg/veg.html';
                    break;
                case 'nonveg':
                    url = '../nonveg/nonveg.html';
                    break;
                case 'vegan':
                    url = '../vegan/vegan.html';
                    break;
                case 'all':
                    url = '../all/all.html';
                    break;
            }
            
            if (url) {
                // Add transition effect before redirecting
                document.body.style.opacity = '0';
                document.body.style.transition = 'opacity 0.5s ease';
                
                setTimeout(() => {
                    window.location.href = url;
                }, 500);
            }
        } else {
            // Animate the options to indicate selection needed
            const options = document.querySelectorAll('.option');
            options.forEach(option => {
                option.style.animation = 'pulse 0.5s ease';
                setTimeout(() => {
                    option.style.animation = '';
                }, 500);
            });
        }
    });
}

function setupProfileButton() {
    const profileBtn = document.getElementById('profileBtn');
    if (!profileBtn) return;
    
    // Clean up any existing event listeners by cloning the node
    const newProfileBtn = profileBtn.cloneNode(true);
    profileBtn.parentNode.replaceChild(newProfileBtn, profileBtn);
    
    // Add new event listener
    newProfileBtn.addEventListener('click', function() {
        // Create a modal for displaying profile information
        const profileModal = document.createElement('div');
        profileModal.style.position = 'fixed';
        profileModal.style.top = '0';
        profileModal.style.left = '0';
        profileModal.style.width = '100%';
        profileModal.style.height = '100%';
        profileModal.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
        profileModal.style.display = 'flex';
        profileModal.style.justifyContent = 'center';
        profileModal.style.alignItems = 'center';
        profileModal.style.zIndex = '1000';
        
        // Sample user data - in a real app, this would come from your database
        const userData = {
            name: "User",
            email: "user@example.com",
            joinDate: "January 15, 2025",
            preferences: "Vegetarian",
            favoriteRecipes: 5
        };
        
        // Create the modal content
        const modalContent = document.createElement('div');
        modalContent.style.backgroundColor = 'white';
        modalContent.style.padding = '2rem';
        modalContent.style.borderRadius = '20px';
        modalContent.style.width = '90%';
        modalContent.style.maxWidth = '500px';
        modalContent.style.boxShadow = '0 10px 30px rgba(0, 0, 0, 0.2)';
        
        // Create modal content HTML
        modalContent.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
                <h2 style="margin: 0; color: #35654d;">Profile Details</h2>
                <button id="closeProfileModal" style="background: none; border: none; font-size: 1.5rem; cursor: pointer; color: #777;">×</button>
            </div>
            <div style="display: flex; align-items: center; margin-bottom: 2rem;">
                <div style="width: 70px; height: 70px; border-radius: 50%; background: linear-gradient(45deg, #4ecdc4, #ff6b6b); display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 2rem; margin-right: 1.5rem;">
                    ${userData.name.charAt(0).toUpperCase()}
                </div>
                <div>
                    <h3 style="margin: 0 0 0.5rem 0;">${userData.name}</h3>
                    <p style="margin: 0; color: #777; font-size: 0.9rem;">Member since ${userData.joinDate}</p>
                </div>
            </div>
            <div style="margin-bottom: 1.5rem;">
                <p style="margin: 0.5rem 0; display: flex; justify-content: space-between;">
                    <span style="color: #777;">Email:</span>
                    <span style="font-weight: 500;">${userData.email}</span>
                </p>
                <p style="margin: 0.5rem 0; display: flex; justify-content: space-between;">
                    <span style="color: #777;">Dietary Preference:</span>
                    <span style="font-weight: 500;">${userData.preferences}</span>
                </p>
                <p style="margin: 0.5rem 0; display: flex; justify-content: space-between;">
                    <span style="color: #777;">Favorite Recipes:</span>
                    <span style="font-weight: 500;">${userData.favoriteRecipes}</span>
                </p>
            </div>
            <div style="display: flex; justify-content: center; gap: 1rem;">
                <button id="editProfileBtn" style="background: linear-gradient(45deg, #4ecdc4, #ff6b6b); color: white; border: none; padding: 0.8rem 2rem; border-radius: 50px; font-weight: 500; cursor: pointer; transition: all 0.3s;">
                    Edit Profile
                </button>
                <button id="changeAvatarBtn" style="background: linear-gradient(45deg, #ffd166, #ff6b6b); color: white; border: none; padding: 0.8rem 2rem; border-radius: 50px; font-weight: 500; cursor: pointer; transition: all 0.3s;">
                    Change Avatar
                </button>
            </div>
        `;
        
        profileModal.appendChild(modalContent);
        document.body.appendChild(profileModal);
        
        // Add event listener to close the modal
        document.getElementById('closeProfileModal').addEventListener('click', function() {
            document.body.removeChild(profileModal);
        });
        
        // Close modal when clicking outside the content
        profileModal.addEventListener('click', function(e) {
            if (e.target === profileModal) {
                document.body.removeChild(profileModal);
            }
        });
        
        // Add event listener for Edit Profile button
        // In setupProfileButton function or where you handle the profile button click
        document.getElementById('profileBtn').addEventListener('click', function() {
    // Update this path to match your actual directory structure
    window.location.href = '/forklore-main/profile/profile.html';
});
        
        // Add event listener for Change Avatar button
        document.getElementById('changeAvatarBtn').addEventListener('click', function() {
            alert('Avatar change functionality will be implemented in the future.');
        });
    });
}

function setupLogoutButton() {
    const logoutBtn = document.getElementById('logoutBtn');
    if (!logoutBtn) return;
    
    // Clean up any existing event listeners by cloning the node
    const newLogoutBtn = logoutBtn.cloneNode(true);
    logoutBtn.parentNode.replaceChild(newLogoutBtn, logoutBtn);
    
    // Add new event listener
    newLogoutBtn.addEventListener('click', function() {
        // Show confirmation dialog
        if (confirm('Are you sure you want to logout?\nClick OK to logout.')) {
            // Create a visible backup link in case auto-redirect fails
            const backupLink = document.createElement('div');
            backupLink.innerHTML = '<div style="position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:white;padding:20px;border-radius:10px;box-shadow:0 0 10px rgba(0,0,0,0.3);z-index:1000;text-align:center;">' +
                '<p>Logging out...</p>' +
                '<p>If you are not redirected automatically, <a href="/forklore-main/landingpage/landingpage.html" style="color:blue;font-weight:bold;">click here</a>.</p>' +
                '</div>';
            document.body.appendChild(backupLink);
            
            // Add fade-out transition
            document.body.style.opacity = '0';
            document.body.style.transition = 'opacity 0.5s ease';
            
            // Try to redirect
            setTimeout(() => {
                window.location.href = '/forklore-main/landingpage/landingpage.html';
            }, 500);
        }
        }
    });
}