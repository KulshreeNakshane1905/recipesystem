_<?php
session_start();
require_once '../db.php';

$error_message = "";
$success_message = "";
$valid_token = false;
$email = "";

// Check if token is provided in the URL
if (isset($_GET['token']) && !empty($_GET['token'])) {
    $token = $_GET['token'];
    
    try {
        // Verify the token
        $stmt = $pdo->prepare("SELECT * FROM password_reset_tokens WHERE token = :token AND expires_at > NOW() LIMIT 1");
        $stmt->bindParam(':token', $token);
        $stmt->execute();
        
        if ($stmt->rowCount() > 0) {
            $token_data = $stmt->fetch(PDO::FETCH_ASSOC);
            $email = $token_data['email'];
            $valid_token = true;
        } else {
            $error_message = "Invalid or expired token. Please request a new password reset link.";
        }
    } catch (PDOException $e) {
        $error_message = "An error occurred. Please try again later.";
        error_log("Token verification error: " . $e->getMessage());
    }
} else {
    $error_message = "Token is missing. Please use the complete link from the reset email.";
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $valid_token) {
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);
    
    // Validate password
    if (empty($password)) {
        $error_message = "Please enter a password.";
    } elseif (strlen($password) < 6) {
        $error_message = "Password must be at least 6 characters long.";
    } elseif ($password !== $confirm_password) {
        $error_message = "Passwords do not match.";
    } else {
        try {
            // Hash the new password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Update the user's password
            $update_stmt = $pdo->prepare("UPDATE users SET password = :password WHERE email = :email");
            $update_stmt->bindParam(':password', $hashed_password);
            $update_stmt->bindParam(':email', $email);
            
            if ($update_stmt->execute()) {
                // Delete the used token
                $delete_stmt = $pdo->prepare("DELETE FROM password_reset_tokens WHERE token = :token");
                $delete_stmt->bindParam(':token', $token);
                $delete_stmt->execute();
                
                $success_message = "Your password has been reset successfully. You can now <a href='signin.php'>sign in</a> with your new password.";
            } else {
                $error_message = "Failed to update password. Please try again.";
            }
        } catch (PDOException $e) {
            $error_message = "An error occurred. Please try again later.";
            error_log("Password reset error: " . $e->getMessage());
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Reset Password</title>
    <link rel="stylesheet" type="text/css" href="../assets/styling/signin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .error-message {
            color: red;
            background-color: rgba(255, 0, 0, 0.1);
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
            text-align: center;
        }
        .success-message {
            color: green;
            background-color: rgba(0, 255, 0, 0.1);
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
            text-align: center;
        }
        .form-container {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
        }
        .input-field {
            position: relative;
            margin-bottom: 20px;
        }
        .input-field i {
            position: absolute;
            left: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
        }
        .input-field input {
            width: 100%;
            padding: 10px 10px 10px 35px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .button {
            width: 100%;
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .button:hover {
            background-color: #45a049;
        }
        .back-link {
            text-align: center;
            margin-top: 15px;
        }
        .password-requirements {
            font-size: 13px;
            color: #666;
            margin-bottom: 15px;
        }
        .pw-strength {
            height: 5px;
            width: 100%;
            margin-top: 5px;
            border-radius: 3px;
            background: #ddd;
            position: relative;
        }
        .pw-strength-bar {
            height: 100%;
            border-radius: 3px;
            transition: width 0.3s ease, background-color 0.3s ease;
            width: 0;
        }
        .weak { background-color: #FF4136; }
        .medium { background-color: #FFDC00; }
        .strong { background-color: #2ECC40; }
    </style>
</head>
<body>
    <div class="form-container">
        <h2 style="text-align: center;">Reset Password</h2>
        
        <?php if (!empty($error_message)): ?>
            <div class="error-message">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($success_message)): ?>
            <div class="success-message">
                <?php echo $success_message; ?>
            </div>
        <?php elseif ($valid_token): ?>
            <form method="post" action="reset_password.php?token=<?php echo htmlspecialchars($token); ?>">
                <div class="password-requirements">
                    Password must be at least 6 characters long and should include a mix of letters, numbers, and special characters for better security.
                </div>
                
                <div class="input-field">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="password" id="password" placeholder="New Password" required>
                </div>
                
                <div class="pw-strength">
                    <div class="pw-strength-bar" id="strength-bar"></div>
                </div>
                
                <div class="input-field">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="confirm_password" placeholder="Confirm Password" required>
                </div>
                
                <button type="submit" class="button">Reset Password</button>
            </form>
        <?php endif; ?>
        
        <div class="back-link">
            <p><a href="signin.php">Back to Sign In</a></p>
        </div>
    </div>
    
    <script>
        // Password strength checker
        const passwordInput = document.getElementById('password');
        const strengthBar = document.getElementById('strength-bar');
        
        if (passwordInput && strengthBar) {
            passwordInput.addEventListener('input', function() {
                const password = this.value;
                let strength = 0;
                
                if (password.length >= 6) {
                    strength += 1;
                }
                
                if (password.match(/[a-z]/) && password.match(/[A-Z]/)) {
                    strength += 1;
                }
                
                if (password.match(/[0-9]/)) {
                    strength += 1;
                }
                
                if (password.match(/[^a-zA-Z0-9]/)) {
                    strength += 1;
                }
                
                switch (strength) {
                    case 0:
                    case 1:
                        strengthBar.className = 'pw-strength-bar weak';
                        strengthBar.style.width = '25%';
                        break;
                    case 2:
                    case 3:
                        strengthBar.className = 'pw-strength-bar medium';
                        strengthBar.style.width = '50%';
                        break;
                    case 4:
                        strengthBar.className = 'pw-strength-bar strong';
                        strengthBar.style.width = '100%';
                        break;
                }
            });
        }
    </script>
</body>
</html>