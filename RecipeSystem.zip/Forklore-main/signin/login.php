<?php
// Include the database connection file
require 'forklore_db'.php; // (your file name)

// Check if form submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form input
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // Validate (basic)
    if (empty($username) || empty($password)) {
        echo "Please fill all fields.";
        exit;
    }

    // Query the database
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username LIMIT 1");
    $stmt->execute(['username' => $username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // You should use password_hash and password_verify ideally
        if ($user['password'] == $password) {
            // Success
            session_start();
            $_SESSION['user_id'] = $user['id'];
            echo "Login successful!";
            // header("Location: dashboard.php"); // Redirect if you want
        } else {
            echo "Invalid password.";
        }
    } else {
        echo "No user found.";
    }
}
?>
