<?php 
session_start(); 
require_once '../db.php';

$signin_error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize inputs
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $password = trim($_POST['password']);
    
    if (!empty($email) && !empty($password)) {
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            try {
                $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email LIMIT 1");
                $stmt->bindParam(':email', $email);
                $stmt->execute();
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($user && password_verify($password, $user['password'])) {
                    // Set session variables
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['email'] = $user['email'];
                    $_SESSION['logged_in'] = true;
                    
                    // Regenerate session ID for security
                    session_regenerate_id(true);
                    
                    // Redirect to dashboard
                    header('Location: ../choicepage/choice.html');
                    exit;
                } else {
                    $signin_error = "Invalid email or password!";
                }
            } catch (PDOException $e) {
                $signin_error = "Database error. Please try again later.";
                // In production, log the error instead of displaying it
                // error_log($e->getMessage());
            }
        } else {
            $signin_error = "Please enter a valid email address.";
        }
    } else {
        $signin_error = "Please fill in all fields.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Welcome Back to Flavorful Finds</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="../assets/styling/signin.css">
    <style>
        :root {
            --primary-color: #FF6B6B;
            --secondary-color: #4ECDC4;
            --accent-color: #FFD166;
            --text-color: #2F4858;
            --background-color: #F7F9FB;
            --input-bg: #fff;
            --success: #6BCB77;
            --error: #FF6B6B;
            --border-radius: 12px;
            --box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Quicksand', 'Segoe UI', sans-serif;
        }
        
        body {
            background-color: var(--background-color);
            background-image: url('/api/placeholder/1920/1080');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            color: var(--text-color);
        }
        
        .signin-container {
            background-color: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: var(--box-shadow);
            overflow: hidden;
            width: 100%;
            max-width: 450px;
            position: relative;
        }
        
        .form-header {
            background-color: var(--secondary-color);
            padding: 30px 20px;
            text-align: center;
            color: white;
            position: relative;
        }
        
        .form-header h2 {
            font-size: 28px;
            margin-bottom: 10px;
            font-weight: 700;
        }
        
        .form-header p {
            opacity: 0.9;
            font-size: 16px;
        }
        
        .recipe-icon {
            position: absolute;
            top: -25px;
            right: -25px;
            background-color: var(--accent-color);
            width: 80px;
            height: 80px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
        }
        
        .recipe-icon i {
            font-size: 36px;
            color: white;
        }
        
        .form-body {
            padding: 30px;
        }
        
        .error-message {
            background-color: rgba(255, 107, 107, 0.1);
            color: var(--error);
            padding: 12px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            font-size: 14px;
            display: flex;
            align-items: center;
        }
        
        .error-message i {
            margin-right: 10px;
            font-size: 16px;
        }
        
        .input-group {
            margin-bottom: 20px;
        }
        
        .input-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            font-size: 14px;
            color: var(--text-color);
        }
        
        .input-field {
            display: flex;
            align-items: center;
            background-color: var(--input-bg);
            border: 2px solid #e1e1e1;
            border-radius: var(--border-radius);
            padding: 10px 15px;
            transition: var(--transition);
        }
        
        .input-field:focus-within {
            border-color: var(--secondary-color);
            box-shadow: 0 0 0 3px rgba(78, 205, 196, 0.2);
        }
        
        .input-field i {
            color: #aaa;
            font-size: 18px;
            margin-right: 10px;
            transition: var(--transition);
        }
        
        .input-field:focus-within i {
            color: var(--secondary-color);
        }
        
        .input-field input {
            flex: 1;
            border: none;
            background: transparent;
            padding: 8px 0;
            font-size: 16px;
            color: var(--text-color);
            width: 100%;
        }
        
        .input-field input:focus {
            outline: none;
        }
        
        .input-field input::placeholder {
            color: #bbb;
            opacity: 1;
        }
        
        .signin-button {
            background-color: var(--secondary-color);
            color: white;
            border: none;
            border-radius: var(--border-radius);
            padding: 15px;
            font-size: 16px;
            font-weight: 700;
            width: 100%;
            cursor: pointer;
            transition: var(--transition);
            margin-top: 10px;
            box-shadow: 0 4px 10px rgba(78, 205, 196, 0.3);
        }
        
        .signin-button:hover {
            background-color: #3dbdad;
            transform: translateY(-2px);
        }
        
        .signin-button:active {
            transform: translateY(0);
        }
        
        .forgot-button {
            background-color: transparent;
            color: var(--text-color);
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            padding: 12px;
            font-size: 14px;
            font-weight: 600;
            width: 100%;
            cursor: pointer;
            transition: var(--transition);
            margin-top: 15px;
            text-align: center;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .forgot-button i {
            margin-right: 8px;
        }
        
        .forgot-button:hover {
            background-color: #f8f8f8;
            border-color: #ccc;
        }
        
        .divider {
            display: flex;
            align-items: center;
            margin: 25px 0;
        }
        
        .divider::before,
        .divider::after {
            content: "";
            flex: 1;
            height: 1px;
            background-color: #ddd;
        }
        
        .divider span {
            padding: 0 15px;
            color: #999;
            font-size: 14px;
        }
        
        .signup-link {
            text-align: center;
            margin-top: 25px;
            font-size: 14px;
        }
        
        .signup-link a {
            color: var(--primary-color);
            font-weight: 700;
            text-decoration: none;
            transition: var(--transition);
        }
        
        .signup-link a:hover {
            text-decoration: underline;
        }
        
        .recipe-tip {
            background-color: rgba(255, 209, 102, 0.1);
            border-left: 4px solid var(--accent-color);
            padding: 15px;
            margin-top: 30px;
            border-radius: 0 var(--border-radius) var(--border-radius) 0;
            font-size: 14px;
        }
        
        .recipe-tip h4 {
            color: var(--text-color);
            margin-bottom: 5px;
            display: flex;
            align-items: center;
        }
        
        .recipe-tip h4 i {
            color: var(--accent-color);
            margin-right: 8px;
        }
        
        .recipe-tip p {
            color: #666;
            line-height: 1.5;
        }
        
        /* Animation */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .form-body {
            animation: fadeIn 0.5s ease-out;
        }
    </style>
</head>
<body>
    <div class="signin-container">
        <div class="form-header">
            <h2>Welcome Back Chef</h2>
            <p>Sign in to access your recipe collection</p>
            <div class="recipe-icon">
                <i class="fas fa-hat-chef"></i>
            </div>
        </div>
        
        <div class="form-body">
            <?php if (!empty($signin_error)): ?>
                <div class="error-message">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo $signin_error; ?>
                </div>
            <?php endif; ?>
            
            <form method="post" action="">
                <div class="input-group">
                    <label class="input-label" for="email">Email Address</label>
                    <div class="input-field">
                        <i class="fas fa-envelope"></i>
                        <input type="email" id="email" name="email" placeholder="Enter your email" required value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                    </div>
                </div>
                
                <div class="input-group">
                    <label class="input-label" for="password">Password</label>
                    <div class="input-field">
                        <i class="fas fa-lock"></i>
                        <input type="password" id="password" name="password" placeholder="Enter your secret ingredient" required>
                    </div>
                </div>
                
                <button type="submit" class="signin-button">
                    Return to Kitchen
                </button>
            </form>
            
            <a href="forgot_password.php" class="forgot-button">
                <i class="fas fa-key"></i> Forgot Your Secret Ingredient?
            </a>
            
            <div class="divider">
                <span>OR</span>
            </div>
            
            <div class="signup-link">
                <p>New to Flavorful Finds? <a href="signup.php">Create an Account</a></p>
            </div>
            
            <div class="recipe-tip">
                <h4><i class="fas fa-lightbulb"></i> Recipe of the Day</h4>
                <p>Try our featured seasonal recipe: Autumn Butternut Squash Soup with toasted pumpkin seeds.</p>
            </div>
        </div>
    </div>
</body>
</html>