// Get DOM Elements
const signInForm = document.querySelector('.sign-in-form');
const signUpForm = document.querySelector('.sign-up-form');
const signUpButton = document.getElementById('sign-up-btn');
const signInButton = document.getElementById('sign-in-btn');
const container = document.querySelector('.container');

// Toggle between sign in and sign up forms
signUpButton.addEventListener('click', () => {
    container.classList.add('sign-up-mode');
});

signInButton.addEventListener('click', () => {
    container.classList.remove('sign-up-mode');
});

// Function to validate email format
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Function to validate password (at least 6 characters)
function isValidPassword(password) {
    return password.length >= 6;
}

// Function to create and display error message
function showError(inputElement, message) {
    // Remove any existing error message
    const existingError = inputElement.parentElement.querySelector('.error-message');
    if (existingError) {
        existingError.remove();
    }
    
    // Create error element
    const errorElement = document.createElement('div');
    errorElement.className = 'error-message';
    errorElement.textContent = message;
    errorElement.style.color = 'red';
    errorElement.style.fontSize = '12px';
    errorElement.style.marginTop = '5px';
    
    // Insert after the input field
    inputElement.parentElement.appendChild(errorElement);
    
    // Highlight the input field
    inputElement.style.borderColor = 'red';
}

// Function to clear error message
function clearError(inputElement) {
    const existingError = inputElement.parentElement.querySelector('.error-message');
    if (existingError) {
        existingError.remove();
    }
    inputElement.style.borderColor = '';
}

// Validate Sign In Form
signInForm.addEventListener('submit', function(event) {
    event.preventDefault();
    
    const username = this.querySelector('input[type="text"]');
    const email = this.querySelector('input[type="email"]');
    const password = this.querySelector('input[type="password"]');
    
    let isValid = true;
    
    // Clear previous errors
    clearError(username);
    clearError(email);
    clearError(password);
    
    // Username validation
    if (username.value.trim() === '') {
        showError(username, 'Username is required');
        isValid = false;
    } else if (username.value.length < 3) {
        showError(username, 'Username must be at least 3 characters');
        isValid = false;
    }
    
    // Email validation
    if (email.value.trim() === '') {
        showError(email, 'Email is required');
        isValid = false;
    } else if (!isValidEmail(email.value)) {
        showError(email, 'Please enter a valid email address');
        isValid = false;
    }
    
    // Password validation
    if (password.value === '') {
        showError(password, 'Password is required');
        isValid = false;
    } else if (!isValidPassword(password.value)) {
        showError(password, 'Password must be at least 6 characters');
        isValid = false;
    }
    
    // If all validations pass, submit the form
    if (isValid) {
        // Here you would normally check against a database
        // For demo purposes, let's say the correct credentials are:
        const validUsername = 'user123';
        const validEmail = 'user@example.com';
        const validPassword = 'password123';
        
        if (username.value === validUsername && 
            email.value === validEmail && 
            password.value === validPassword) {
            this.submit();
        } else {
            alert('Invalid username, email, or password. Please try again.');
        }
    }
});

// Validate Sign Up Form
signUpForm.addEventListener('submit', function(event) {
    event.preventDefault();
    
    const username = this.querySelector('input[type="text"]');
    const email = this.querySelector('input[type="email"]');
    const password = this.querySelector('input[type="password"]');
    
    let isValid = true;
    
    // Clear previous errors
    clearError(username);
    clearError(email);
    clearError(password);
    
    // Username validation
    if (username.value.trim() === '') {
        showError(username, 'Username is required');
        isValid = false;
    } else if (username.value.length < 3) {
        showError(username, 'Username must be at least 3 characters');
        isValid = false;
    }
    
    // Email validation
    if (email.value.trim() === '') {
        showError(email, 'Email is required');
        isValid = false;
    } else if (!isValidEmail(email.value)) {
        showError(email, 'Please enter a valid email address');
        isValid = false;
    }
    
    // Password validation
    if (password.value === '') {
        showError(password, 'Password is required');
        isValid = false;
    } else if (!isValidPassword(password.value)) {
        showError(password, 'Password must be at least 6 characters');
        isValid = false;
    }
    
    // If all validations pass, submit the form
    if (isValid) {
        this.submit();
    }
});