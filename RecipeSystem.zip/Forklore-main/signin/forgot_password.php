<?php
session_start();
require_once '../db.php';

$error_message = "";
$success_message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    
    if (empty($email)) {
        $error_message = "Please enter your email address.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "Please enter a valid email address.";
    } else {
        try {
            // Check if the email exists in the database
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email LIMIT 1");
            $stmt->bindParam(':email', $email);
            $stmt->execute();
            
            if ($stmt->rowCount() > 0) {
                // Generate a unique token
                $token = bin2hex(random_bytes(32));
                $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
                
                // First, delete any existing reset tokens for this email
                $delete_stmt = $pdo->prepare("DELETE FROM password_reset_tokens WHERE email = :email");
                $delete_stmt->bindParam(':email', $email);
                $delete_stmt->execute();
                
                // Insert the new token
                $insert_stmt = $pdo->prepare("INSERT INTO password_reset_tokens (email, token, expires_at) VALUES (:email, :token, :expires)");
                $insert_stmt->bindParam(':email', $email);
                $insert_stmt->bindParam(':token', $token);
                $insert_stmt->bindParam(':expires', $expires);
                $insert_stmt->execute();
                
                // In a real application, you would send an email with the reset link
                // For this example, we'll just display the link
                $reset_link = "http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/reset_password.php?token=" . $token;
                
                $success_message = "Password reset link has been sent to your email. Check your inbox.<br><br>For development purposes, here's the link: <a href='$reset_link'>$reset_link</a>";
                
                // In production, you would use a mail library like PHPMailer to send an actual email
                // Example of email sending code (commented out):
                /*
                $to = $email;
                $subject = "Password Reset for Forklore";
                $message = "Hello,\n\nYou requested a password reset for your Forklore account.\n\nClick the following link to reset your password: $reset_link\n\nThis link will expire in 1 hour.\n\nIf you did not request this reset, please ignore this email.\n\nRegards,\nForklore Team";
                $headers = "From: noreply@forklore.com";
                mail($to, $subject, $message, $headers);
                */
            } else {
                // Don't reveal if the email exists for security reasons
                $success_message = "If your email is registered with us, you will receive a password reset link.";
            }
        } catch (PDOException $e) {
            $error_message = "An error occurred. Please try again later.";
            // Log the error
            error_log("Password reset error: " . $e->getMessage());
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Forgot Password</title>
    <link rel="stylesheet" type="text/css" href="../assets/styling/signin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .error-message {
            color: red;
            background-color: rgba(255, 0, 0, 0.1);
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
            text-align: center;
        }
        .success-message {
            color: green;
            background-color: rgba(0, 255, 0, 0.1);
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
            text-align: center;
        }
        .form-container {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
        }
        .input-field {
            position: relative;
            margin-bottom: 20px;
        }
        .input-field i {
            position: absolute;
            left: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
        }
        .input-field input {
            width: 100%;
            padding: 10px 10px 10px 35px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .button {
            width: 100%;
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .button:hover {
            background-color: #45a049;
        }
        .back-link {
            text-align: center;
            margin-top: 15px;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2 style="text-align: center;">Forgot Password</h2>
        
        <?php if (!empty($error_message)): ?>
            <div class="error-message">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($success_message)): ?>
            <div class="success-message">
                <?php echo $success_message; ?>
            </div>
        <?php else: ?>
            <p style="text-align: center;">Enter your email address below and we'll send you a link to reset your password.</p>
            
            <form method="post" action="">
                <div class="input-field">
                    <i class="fas fa-envelope"></i>
                    <input type="email" name="email" placeholder="Email" required value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                </div>
                
                <button type="submit" class="button">Send Reset Link</button>
            </form>
        <?php endif; ?>
        
        <div class="back-link">
            <p><a href="signin.php">Back to Sign In</a></p>
        </div>
    </div>
</body>
</html>