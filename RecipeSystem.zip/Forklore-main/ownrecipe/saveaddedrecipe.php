<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Set headers to return JSON
header('Content-Type: application/json');

// Log file for debugging
$logFile = 'recipe_submission_log.txt';
function logMessage($message) {
    global $logFile;
    file_put_contents($logFile, date('[Y-m-d H:i:s] ') . $message . "\n", FILE_APPEND);
}

logMessage("Recipe submission started");

// Database credentials
$host = 'localhost';
$dbname = 'forklore_db';  // Your database name
$username = 'root';    // Default XAMPP username
$password = '';        // Default XAMPP password (empty)

try {
    // Create database connection
    logMessage("Attempting database connection");
    $conn = new mysqli($host, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
        logMessage("Database connection failed: " . $conn->connect_error);
        die(json_encode(['success' => false, 'message' => 'Database connection failed: ' . $conn->connect_error]));
    }
    
    logMessage("Database connection successful");
    
    // Validate required fields
    $requiredFields = ['name', 'description', 'category', 'difficulty', 'prepTime', 'cookTime', 'servings'];
    foreach ($requiredFields as $field) {
        if (!isset($_POST[$field]) || empty(trim($_POST[$field]))) {
            logMessage("Missing required field: $field");
            die(json_encode(['success' => false, 'message' => "Missing required field: $field"]));
        }
    }
    
    logMessage("Required fields validation passed");
    
    // Collect form data
    $recipeName = $conn->real_escape_string($_POST['name']);
    $recipeDescription = $conn->real_escape_string($_POST['description']);
    $recipeCategory = $conn->real_escape_string($_POST['category']);
    $difficulty = $conn->real_escape_string($_POST['difficulty']);
    $prepTime = (int)$_POST['prepTime'];
    $cookTime = (int)$_POST['cookTime'];
    $servings = (int)$_POST['servings'];
    $notes = isset($_POST['notes']) ? $conn->real_escape_string($_POST['notes']) : '';
    
    logMessage("Form data collected");
    
    // Handle image upload
    $imagePath = null;
    if (!empty($_FILES['image']['name'])) {
        logMessage("Processing image upload");
        
        // Create uploads directory if it doesn't exist
        $uploadDir = 'uploads/';
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
            logMessage("Created uploads directory");
        }
        
        $fileName = uniqid() . '_' . basename($_FILES['image']['name']);
        $targetFile = $uploadDir . $fileName;
        
        // Check file type
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        if (!in_array($_FILES['image']['type'], $allowedTypes)) {
            logMessage("Invalid file type: " . $_FILES['image']['type']);
            die(json_encode(['success' => false, 'message' => 'Only JPG, PNG, GIF, and WEBP files are allowed']));
        }
        
        // Upload the file
        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
            $imagePath = $targetFile;
            logMessage("Image uploaded successfully: $targetFile");
        } else {
            logMessage("Image upload failed");
            die(json_encode(['success' => false, 'message' => 'Image upload failed']));
        }
    } else {
        logMessage("No image uploaded");
    }
    
    // First check if the tables exist
    $tablesExist = true;
    $requiredTables = ['recipes', 'recipe_ingredients', 'recipe_instructions'];
    
    foreach ($requiredTables as $table) {
        $result = $conn->query("SHOW TABLES LIKE '$table'");
        if ($result->num_rows == 0) {
            $tablesExist = false;
            logMessage("Required table missing: $table");
        }
    }
    
    if (!$tablesExist) {
        logMessage("Creating database tables");
        
        // Create recipes table
        $conn->query("CREATE TABLE IF NOT EXISTS recipes (
            id INT(11) AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            description TEXT NOT NULL,
            category VARCHAR(50) NOT NULL,
            difficulty VARCHAR(50) NOT NULL,
            prep_time INT(11) NOT NULL,
            cook_time INT(11) NOT NULL,
            servings INT(11) NOT NULL,
            notes TEXT,
            image_path VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )");
        
        // Create ingredients table
        $conn->query("CREATE TABLE IF NOT EXISTS recipe_ingredients (
            id INT(11) AUTO_INCREMENT PRIMARY KEY,
            recipe_id INT(11) NOT NULL,
            ingredient TEXT NOT NULL,
            FOREIGN KEY (recipe_id) REFERENCES recipes(id) ON DELETE CASCADE
        )");
        
        // Create instructions table
        $conn->query("CREATE TABLE IF NOT EXISTS recipe_instructions (
            id INT(11) AUTO_INCREMENT PRIMARY KEY,
            recipe_id INT(11) NOT NULL,
            step TEXT NOT NULL,
            FOREIGN KEY (recipe_id) REFERENCES recipes(id) ON DELETE CASCADE
        )");
        
        logMessage("Database tables created");
    }
    
    // Start transaction
    logMessage("Starting database transaction");
    $conn->begin_transaction();
    
    try {
        // Insert recipe into the database
        $stmt = $conn->prepare("INSERT INTO recipes (name, description, category, difficulty, prep_time, cook_time, servings, notes, image_path) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        if (!$stmt) {
            throw new Exception("Prepare statement failed: " . $conn->error);
        }
        
        $stmt->bind_param("ssssiiiss", $recipeName, $recipeDescription, $recipeCategory, $difficulty, $prepTime, $cookTime, $servings, $notes, $imagePath);
        if (!$stmt->execute()) {
            throw new Exception("Execute failed: " . $stmt->error);
        }
        
        $recipeId = $stmt->insert_id;
        $stmt->close();
        
        logMessage("Recipe inserted with ID: $recipeId");
        
        // Handle ingredients
        if (isset($_POST['ingredients']) && is_array($_POST['ingredients'])) {
            logMessage("Processing ingredients");
            
            $ingStmt = $conn->prepare("INSERT INTO recipe_ingredients (recipe_id, ingredient) VALUES (?, ?)");
            if (!$ingStmt) {
                throw new Exception("Prepare ingredients statement failed: " . $conn->error);
            }
            
            foreach ($_POST['ingredients'] as $ingredient) {
                $ingredient = trim($ingredient);
                if (!empty($ingredient)) {
                    $ingredientEscaped = $conn->real_escape_string($ingredient);
                    $ingStmt->bind_param("is", $recipeId, $ingredientEscaped);
                    if (!$ingStmt->execute()) {
                        throw new Exception("Execute ingredient insert failed: " . $ingStmt->error);
                    }
                }
            }
            $ingStmt->close();
            logMessage("Ingredients processed successfully");
        }
        
        // Handle instructions
        if (isset($_POST['instructions']) && is_array($_POST['instructions'])) {
            logMessage("Processing instructions");
            
            $insStmt = $conn->prepare("INSERT INTO recipe_instructions (recipe_id, step) VALUES (?, ?)");
            if (!$insStmt) {
                throw new Exception("Prepare instructions statement failed: " . $conn->error);
            }

            foreach ($_POST['instructions'] as $instruction) {
                $instruction = trim($instruction);
                if (!empty($instruction)) {
                    $instructionEscaped = $conn->real_escape_string($instruction);
                    $insStmt->bind_param("is", $recipeId, $instructionEscaped);
                    if (!$insStmt->execute()) {
                        throw new Exception("Execute instruction insert failed: " . $insStmt->error);
                    }
                }
            }
            $insStmt->close();
            logMessage("Instructions processed successfully");
        }
        
        // Commit transaction
        $conn->commit();
        logMessage("Transaction committed successfully");
        
        // Return success response
        echo json_encode(['success' => true, 'message' => 'Recipe submitted successfully', 'recipeId' => $recipeId]);
        
    } catch (Exception $e) {
        // Rollback transaction on error
        $conn->rollback();
        logMessage("Error in transaction: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
} catch (Exception $e) {
    logMessage("Fatal error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'System error: ' . $e->getMessage()]);
}

// Close connection if it exists
if (isset($conn) && $conn instanceof mysqli) {
    $conn->close();
    logMessage("Database connection closed");
}

logMessage("Recipe submission process completed");
?>