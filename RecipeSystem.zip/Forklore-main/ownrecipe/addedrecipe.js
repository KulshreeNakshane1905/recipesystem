document.addEventListener('DOMContentLoaded', function() {
    // Set up dynamic ingredients and instructions
    document.getElementById('addIngredient').addEventListener('click', function() {
        const ingredientsList = document.getElementById('ingredientsList');
        const newIngredient = document.createElement('div');
        newIngredient.className = 'ingredient-entry';
        newIngredient.innerHTML = `
            <input type="text" name="ingredients[]" placeholder="e.g. 2 cups all-purpose flour, sifted" required>
            <button type="button" class="remove-btn"><i class="fas fa-times"></i></button>
        `;
        ingredientsList.appendChild(newIngredient);
        
        // Show all remove buttons when we have more than one ingredient
        if (ingredientsList.children.length > 1) {
            const removeButtons = ingredientsList.querySelectorAll('.remove-btn');
            removeButtons.forEach(btn => btn.style.display = 'inline-block');
        }
        
        // Add event listener to the new remove button
        newIngredient.querySelector('.remove-btn').addEventListener('click', function() {
            ingredientsList.removeChild(newIngredient);
            // Hide the remove button on the last remaining ingredient
            if (ingredientsList.children.length === 1) {
                ingredientsList.querySelector('.remove-btn').style.display = 'none';
            }
        });
    });
    
    document.getElementById('addInstruction').addEventListener('click', function() {
        const instructionsList = document.getElementById('instructionsList');
        const newInstruction = document.createElement('div');
        newInstruction.className = 'instruction-entry';
        newInstruction.innerHTML = `
            <textarea name="instructions[]" rows="2" placeholder="Describe this step in detail..." required></textarea>
            <button type="button" class="remove-btn"><i class="fas fa-times"></i></button>
        `;
        instructionsList.appendChild(newInstruction);
        
        // Show all remove buttons when we have more than one instruction
        if (instructionsList.children.length > 1) {
            const removeButtons = instructionsList.querySelectorAll('.remove-btn');
            removeButtons.forEach(btn => btn.style.display = 'inline-block');
        }
        
        // Add event listener to the new remove button
        newInstruction.querySelector('.remove-btn').addEventListener('click', function() {
            instructionsList.removeChild(newInstruction);
            // Hide the remove button on the last remaining instruction
            if (instructionsList.children.length === 1) {
                instructionsList.querySelector('.remove-btn').style.display = 'none';
            }
        });
    });
    
    // Image preview functionality
    document.getElementById('image').addEventListener('change', function(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const imagePreview = document.getElementById('imagePreview');
                imagePreview.src = e.target.result;
                document.getElementById('imagePreviewContainer').style.display = 'block';
            };
            reader.readAsDataURL(file);
        }
    });

    // Handle form navigation
    window.nextStep = function(step) {
        document.querySelectorAll('.form-section').forEach(sec => sec.classList.remove('active'));
        document.getElementById('step' + step).classList.add('active');
        
        // Add visual feedback for completed steps
        if (step > 1) {
            for (let i = 1; i < step; i++) {
                document.getElementById('step' + i).classList.add('completed');
            }
        }
    };

    // Handle the form submission with AJAX
    document.getElementById('recipeForm').addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent normal form submission

        // Validate required fields
        const allRequiredFields = document.querySelectorAll('[required]');
        let isValid = true;
        
        allRequiredFields.forEach(field => {
            if (!field.value.trim()) {
                isValid = false;
                field.classList.add('invalid');
            } else {
                field.classList.remove('invalid');
            }
        });

        if (!isValid) {
            alert('Please fill in all required fields before submitting.');
            return;
        }

        // Prepare form data for submission
        const formData = new FormData(this);
        
        // Create loading indicator
        const submitBtn = document.querySelector('.submit-btn');
        const originalBtnText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';
        submitBtn.disabled = true;

        // Send form data to the server via AJAX
        fetch('saveaddedrecipe.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Show brief success message
                alert('Recipe submitted successfully! Redirecting...');
                
                // Redirect to the choice page
                window.location.href = '../choicepage/choice.html'; // Change to your actual choice page URL
                
                // Note: The code below won't execute due to the redirect
                // But we'll keep it in case you decide to change the implementation
                
                // Reset form and UI after successful submission
                this.reset();
                
                // Reset form to step 1 using consistent class-based navigation
                document.querySelectorAll('.form-section').forEach(sec => {
                    sec.classList.remove('active', 'completed');
                });
                document.getElementById('step1').classList.add('active');
                
                // Reset image preview
                document.getElementById('imagePreviewContainer').style.display = 'none';
                submitBtn.innerHTML = originalBtnText;
                submitBtn.disabled = false;
                
                // Clear dynamic fields
                document.getElementById('ingredientsList').innerHTML = `
                    <div class="ingredient-entry">
                        <input type="text" name="ingredients[]" placeholder="e.g. 2 cups all-purpose flour, sifted" required>
                        <button type="button" class="remove-btn" style="display: none;"><i class="fas fa-times"></i></button>
                    </div>
                `;
                document.getElementById('instructionsList').innerHTML = `
                    <div class="instruction-entry">
                        <textarea name="instructions[]" rows="2" placeholder="Describe this step in detail..." required></textarea>
                        <button type="button" class="remove-btn" style="display: none;"><i class="fas fa-times"></i></button>
                    </div>
                `;
            } else {
                alert('Error: ' + data.message);
                submitBtn.innerHTML = originalBtnText;
                submitBtn.disabled = false;
            }
        })
        .catch(error => {
            alert('An error occurred while submitting your recipe. Please try again.');
            console.error('Error:', error);
            submitBtn.innerHTML = originalBtnText;
            submitBtn.disabled = false;
        });
    });
});