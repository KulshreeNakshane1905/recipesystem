<?php
include '../config/db_connect.php';
include '../includes/header.php';

// Initialize variables
$ingredient_id = '';
$ingredient_name = '';
$cost_per_unit = '';
$unit = '';
$error_message = '';
$success_message = '';

// Check if ingredient ID is provided
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $ingredient_id = $_GET['id'];
    $conn = connectDB();
    
    // Fetch ingredient details
    $sql = "SELECT * FROM ingredients WHERE ingredient_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $ingredient_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $ingredient = $result->fetch_assoc();
        $ingredient_name = $ingredient['ingredient_name'];
        $cost_per_unit = $ingredient['cost_per_unit'];
        $unit = $ingredient['unit'];
    } else {
        $error_message = "Ingredient not found!";
    }
    
    $stmt->close();
} else {
    $error_message = "Invalid ingredient ID!";
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize input
    $ingredient_id = filter_input(INPUT_POST, 'ingredient_id', FILTER_SANITIZE_NUMBER_INT);
    $ingredient_name = filter_input(INPUT_POST, 'ingredient_name', FILTER_SANITIZE_SPECIAL_CHARS);
    $cost_per_unit = filter_input(INPUT_POST, 'cost_per_unit', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
    $unit = filter_input(INPUT_POST, 'unit', FILTER_SANITIZE_SPECIAL_CHARS);
    
    // Validation checks
    $errors = [];
    
    if (empty($ingredient_name)) {
        $errors[] = "Ingredient name is required";
    }
    
    if (empty($cost_per_unit) || !is_numeric($cost_per_unit) || $cost_per_unit <= 0) {
        $errors[] = "Valid cost per unit is required (must be a positive number)";
    }
    
    if (empty($unit)) {
        $errors[] = "Unit of measurement is required";
    }
    
    // If no errors, update the ingredient
    if (empty($errors)) {
        $conn = connectDB();
        
        $sql = "UPDATE ingredients SET ingredient_name = ?, cost_per_unit = ?, unit = ? WHERE ingredient_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sdsi", $ingredient_name, $cost_per_unit, $unit, $ingredient_id);
        
        if ($stmt->execute()) {
            $success_message = "Ingredient updated successfully!";
            
            // Refresh ingredient data
            $sql = "SELECT * FROM ingredients WHERE ingredient_id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $ingredient_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $ingredient = $result->fetch_assoc();
                $ingredient_name = $ingredient['ingredient_name'];
                $cost_per_unit = $ingredient['cost_per_unit'];
                $unit = $ingredient['unit'];
            }
        } else {
            $error_message = "Error updating ingredient: " . $conn->error;
        }
        
        $stmt->close();
    } else {
        $error_message = "Please correct the following errors: <br>" . implode("<br>", $errors);
    }
}
?>

<div class="container">
    <h1>Edit Ingredient</h1>
    
    <?php if (!empty($error_message)): ?>
        <div class="error-message">
            <?php echo $error_message; ?>
        </div>
    <?php endif; ?>
    
    <?php if (!empty($success_message)): ?>
        <div class="success-message">
            <?php echo $success_message; ?>
        </div>
    <?php endif; ?>
    
    <?php if (empty($error_message) || !empty($ingredient_id)): ?>
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . "?id=" . $ingredient_id; ?>">
            <input type="hidden" name="ingredient_id" value="<?php echo $ingredient_id; ?>">
            
            <div class="form-group">
                <label for="ingredient_name">Ingredient Name:</label>
                <input type="text" id="ingredient_name" name="ingredient_name" value="<?php echo htmlspecialchars($ingredient_name); ?>" required>
            </div>
            
            <div class="form-group">
                <label for="cost_per_unit">Cost per Unit:</label>
                <input type="number" id="cost_per_unit" name="cost_per_unit" value="<?php echo htmlspecialchars($cost_per_unit); ?>" step="0.01" min="0.01" required>
            </div>
            
            <div class="form-group">
                <label for="unit">Unit of Measurement:</label>
                <select id="unit" name="unit" required>
                    <option value="">Select a unit</option>
                    <option value="g" <?php echo ($unit == 'g') ? 'selected' : ''; ?>>Gram (g)</option>
                    <option value="kg" <?php echo ($unit == 'kg') ? 'selected' : ''; ?>>Kilogram (kg)</option>
                    <option value="oz" <?php echo ($unit == 'oz') ? 'selected' : ''; ?>>Ounce (oz)</option>
                    <option value="lb" <?php echo ($unit == 'lb') ? 'selected' : ''; ?>>Pound (lb)</option>
                    <option value="ml" <?php echo ($unit == 'ml') ? 'selected' : ''; ?>>Milliliter (ml)</option>
                    <option value="L" <?php echo ($unit == 'L') ? 'selected' : ''; ?>>Liter (L)</option>
                    <option value="tsp" <?php echo ($unit == 'tsp') ? 'selected' : ''; ?>>Teaspoon (tsp)</option>
                    <option value="tbsp" <?php echo ($unit == 'tbsp') ? 'selected' : ''; ?>>Tablespoon (tbsp)</option>
                    <option value="cup" <?php echo ($unit == 'cup') ? 'selected' : ''; ?>>Cup</option>
                    <option value="piece" <?php echo ($unit == 'piece') ? 'selected' : ''; ?>>Piece</option>
                    <option value="package" <?php echo ($unit == 'package') ? 'selected' : ''; ?>>Package</option>
                </select>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn btn-primary">Update Ingredient</button>
                <a href="../ingredients/view_ingredients.php" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    <?php endif; ?>
</div>

<?php
if (isset($conn) && $conn) {
    $conn->close();
}
include '../includes/footer.php';
?>