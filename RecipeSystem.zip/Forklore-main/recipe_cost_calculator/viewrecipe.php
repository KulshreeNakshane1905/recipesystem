<?php
// recipes/view_recipe.php
include '../config/db_connect.php';
include '../includes/header.php';
require_once 'recipe_functions.php';

// Check if ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
  $_SESSION['message'] = "Invalid recipe ID";
  $_SESSION['message_type'] = "error";
  header("Location: ../index.php");
  exit();
}

$recipeId = intval($_GET['id']);
$recipe = getRecipeById($recipeId);

// Check if recipe exists
if (!$recipe) {
  $_SESSION['message'] = "Recipe not found";
  $_SESSION['message_type'] = "error";
  header("Location: ../index.php");
  exit();
}

// Get recipe ingredients
$ingredients = getRecipeIngredients($recipeId);

// Calculate costs
$totalCost = calculateRecipeCost($recipeId);
$costPerServing = calculateCostPerServing($recipeId);
?>

<div class="container">
  <h1><?php echo htmlspecialchars($recipe['recipe_name']); ?></h1>
  
  <div class="recipe-details">
    <div class="recipe-meta">
      <div>
        <strong>Servings:</strong> <?php echo $recipe['servings']; ?>
      </div>
      <?php if($recipe['preparation_time']): ?>
      <div>
        <strong>Preparation Time:</strong> <?php echo $recipe['preparation_time']; ?> minutes
      </div>
      <?php endif; ?>
      <div>
        <strong>Created:</strong> <?php echo date('M j, Y', strtotime($recipe['created_at'])); ?>
      </div>
    </div>
    
    <?php if($recipe['description']): ?>
    <div class="description">
      <p><?php echo nl2br(htmlspecialchars($recipe['description'])); ?></p>
    </div>
    <?php endif; ?>
    
    <h2>Ingredients</h2>
    
    <div class="table-container">
      <table class="ingredient-list">
        <thead>
          <tr>
            <th>Ingredient</th>
            <th>Quantity</th>
            <th>Cost Per Unit</th>
            <th>Total Cost</th>
            <th>Percentage</th>
          </tr>
        </thead>
        <tbody>
          <?php if(count($ingredients) > 0): ?>
            <?php foreach($ingredients as $ingredient): ?>
              <?php $ingredientCost = $ingredient['quantity'] * $ingredient['cost_per_unit']; ?>
              <?php $percentage = $totalCost > 0 ? ($ingredientCost / $totalCost) * 100 : 0; ?>
              <tr class="ingredient-row">
                <td><?php echo htmlspecialchars($ingredient['ingredient_name']); ?></td>
                <td><?php echo $ingredient['quantity']; ?> <?php echo $ingredient['unit']; ?></td>
                <td>$<?php echo number_format($ingredient['cost_per_unit'], 2); ?></td>
                <td>
                  $<span class="total-cost" data-cost="<?php echo $ingredientCost; ?>">
                    <?php echo number_format($ingredientCost, 2); ?>
                  </span>
                </td>
                <td>
                  <span class="cost-percentage" data-cost="<?php echo $ingredientCost; ?>">
                    <?php echo number_format($percentage, 1); ?>%
                  </span>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr>
              <td colspan="5">No ingredients added to this recipe yet.</td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
    
    <div class="cost-breakdown">
      <h3>Cost Summary</h3>
      <p><strong>Total Recipe Cost:</strong> $<span id="total-cost"><?php echo number_format($totalCost, 2); ?></span></p>
      <p><strong>Cost Per Serving:</strong> $<span id="cost-per-serving"><?php echo number_format($costPerServing, 2); ?></span></p>
    </div>
    
    <div style="margin-top: 2rem;">
      <a href="edit_recipe.php?id=<?php echo $recipeId; ?>" class="btn">Edit Recipe</a>
      <a href="delete_recipe.php?id=<?php echo $recipeId; ?>" class="btn btn-danger" 
         onclick="return confirm('Are you sure you want to delete this recipe?')">Delete Recipe</a>
      <a href="../index.php" class="btn" style="background-color: var(--dark-grey);">Back to Recipes</a>
    </div>
  </div>
</div>

<?php include '../includes/footer.php'; ?>