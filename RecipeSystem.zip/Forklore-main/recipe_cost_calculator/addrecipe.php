<?php
// recipes/add_recipe.php
include '../config/db_connect.php';
include '../includes/header.php';
require_once 'recipe_functions.php';

$conn = connectDB();

// Get all ingredients for the dropdown
$sql = "SELECT * FROM ingredients ORDER BY ingredient_name";
$result = $conn->query($sql);
$ingredients = [];

if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $ingredients[] = $row;
  }
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Sanitize and validate input
  $recipeName = htmlspecialchars($_POST['recipe_name']);
  $description = htmlspecialchars($_POST['description']);
  $servings = intval($_POST['servings']);
  $preparationTime = intval($_POST['preparation_time']);
  
  // Validate recipe name
  if (empty($recipeName)) {
    $_SESSION['message'] = "Recipe name is required";
    $_SESSION['message_type'] = "error";
  } else {
    // Add recipe to database
    $recipeId = addRecipe($recipeName, $description, $servings, $preparationTime);
    
    if ($recipeId) {
      // Process ingredients
      if (isset($_POST['ingredient_id']) && is_array($_POST['ingredient_id'])) {
        $ingredient_ids = $_POST['ingredient_id'];
        $quantities = $_POST['quantity'];
        
        for ($i = 0; $i < count($ingredient_ids); $i++) {
          $ingredientId = intval($ingredient_ids[$i]);
          $quantity = floatval($quantities[$i]);
          
          if ($ingredientId > 0 && $quantity > 0) {
            addIngredientToRecipe($recipeId, $ingredientId, $quantity);
          }
        }
      }
      
      $_SESSION['message'] = "Recipe added successfully";
      $_SESSION['message_type'] = "success";
      header("Location: ../index.php");
      exit();
    } else {
      $_SESSION['message'] = "Error adding recipe";
      $_SESSION['message_type'] = "error";
    }
  }
}
?>

<div class="container">
  <h1>Add New Recipe</h1>
  
  <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <div class="form-group">
      <label for="recipe_name">Recipe Name *</label>
      <input type="text" id="recipe_name" name="recipe_name" required>
    </div>
    
    <div class="form-group">
      <label for="description">Description</label>
      <textarea id="description" name="description" rows="3"></textarea>
    </div>
    
    <div class="form-group">
      <label for="servings">Number of Servings *</label>
      <input type="number" id="servings" name="servings" min="1" value="1" required>
    </div>
    
    <div class="form-group">
      <label for="preparation_time">Preparation Time (minutes)</label>
      <input type="number" id="preparation_time" name="preparation_
      <input type="number" id="preparation_time" name="preparation_time" min="0" value="0">
    </div>
    
    <h2>Ingredients</h2>
    <p>Add ingredients to your recipe:</p>
    
    <div class="ingredients-container">
      <div class="ingredient-row">
        <div>
          <select name="ingredient_id[]" class="ingredient-select" required>
            <option value="">Select an ingredient</option>
            <?php foreach ($ingredients as $ingredient): ?>
              <option value="<?php echo $ingredient['ingredient_id']; ?>" 
                      data-cost="<?php echo $ingredient['cost_per_unit']; ?>"
                      data-unit="<?php echo $ingredient['unit']; ?>">
                <?php echo $ingredient['ingredient_name']; ?> 
                ($<?php echo number_format($ingredient['cost_per_unit'], 2); ?>/<?php echo $ingredient['unit']; ?>)
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <input type="number" name="quantity[]" class="quantity" min="0.01" step="0.01" value="1" required>
        </div>
        <div>
          <span class="unit"></span>
        </div>
        <div>
          <span class="remove-ingredient">✕</span>
        </div>
      </div>
    </div>
    
    <button type="button" id="add-ingredient" class="btn">Add Another Ingredient</button>
    
    <div class="form-group" style="margin-top: 2rem;">
      <button type="submit" class="btn">Save Recipe</button>
      <a href="../index.php" class="btn" style="background-color: var(--dark-grey);">Cancel</a>
    </div>
  </form>
  
  <!-- Template for new ingredient rows -->
  <template id="ingredient-template">
    <div class="ingredient-row">
      <div>
        <select name="ingredient_id[]" class="ingredient-select" required>
          <option value="">Select an ingredient</option>
          <?php foreach ($ingredients as $ingredient): ?>
            <option value="<?php echo $ingredient['ingredient_id']; ?>" 
                    data-cost="<?php echo $ingredient['cost_per_unit']; ?>"
                    data-unit="<?php echo $ingredient['unit']; ?>">
              <?php echo $ingredient['ingredient_name']; ?> 
              ($<?php echo number_format($ingredient['cost_per_unit'], 2); ?>/<?php echo $ingredient['unit']; ?>)
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <input type="number" name="quantity[]" class="quantity" min="0.01" step="0.01" value="1" required>
      </div>
      <div>
        <span class="unit"></span>
      </div>
      <div>
        <span class="remove-ingredient">✕</span>
      </div>
    </div>
  </template>
</div>

<script>
  // Additional JavaScript for this page
  document.addEventListener('DOMContentLoaded', function() {
    // Update unit when ingredient is selected
    document.querySelectorAll('.ingredient-select').forEach(select => {
      select.addEventListener('change', function() {
        const selectedOption = this.options[this.selectedIndex];
        const unitSpan = this.closest('.ingredient-row').querySelector('.unit');
        
        if (selectedOption.dataset.unit) {
          unitSpan.textContent = selectedOption.dataset.unit;
        } else {
          unitSpan.textContent = '';
        }
      });
    });
  });
</script>

<?php
$conn->close();
include '../includes/footer.php';
?>