<?php
// includes/header.php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Recipe Cost Calculator</title>
  <link rel="stylesheet" href="/recipe_cost_calculator/css/style.css">
</head>
<body>
  <header>
    <nav>
      <div class="logo">Recipe Cost Calculator</div>
      <ul>
        <li><a href="/recipe_cost_calculator/index.php">Home</a></li>
        <li><a href="/recipe_cost_calculator/recipes/add_recipe.php">Add Recipe</a></li>
        <li><a href="/recipe_cost_calculator/ingredients/add_ingredient.php">Add Ingredient</a></li>
        <li><a href="/recipe_cost_calculator/ingredients/index.php">Ingredients</a></li>
      </ul>
    </nav>
  </header>
  
  <div class="messages">
    <?php if(isset($_SESSION['message'])): ?>
      <div class="message <?php echo $_SESSION['message_type']; ?>">
        <?php 
          echo $_SESSION['message']; 
          unset($_SESSION['message']);
          unset($_SESSION['message_type']);
        ?>
      </div>
    <?php endif; ?>
  </div>
  
  <main>