<?php
// recipes/edit_recipe.php
include '../config/db_connect.php';
include '../includes/header.php';
require_once 'recipe_functions.php';

$conn = connectDB();

// Check if ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
  $_SESSION['message'] = "Invalid recipe ID";
  $_SESSION['message_type'] = "error";
  header("Location: ../index.php");
  exit();
}

$recipeId = intval($_GET['id']);
$recipe = getRecipeById($recipeId);

// Check if recipe exists
if (!$recipe) {
  $_SESSION['message'] = "Recipe not found";
  $_SESSION['message_type'] = "error";
  header("Location: ../index.php");
  exit();
}

// Get all ingredients for the dropdown
$sql = "SELECT * FROM ingredients ORDER BY ingredient_name";
$result = $conn->query($sql);
$allIngredients = [];

if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $allIngredients[] = $row;
  }
}

// Get current recipe ingredients
$recipeIngredients = getRecipeIngredients($recipeId);

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Sanitize and validate input
  $recipeName = htmlspecialchars($_POST['recipe_name']);
  $description = htmlspecialchars($_POST['description']);
  $servings = intval($_POST['servings']);
  $preparationTime = intval($_POST['preparation_time']);
  
  // Validate recipe name
  if (empty($recipeName)) {
    $_SESSION['message'] = "Recipe name is required";
    $_SESSION['message_type'] = "error";
  } else {
    // Update recipe in database
    $success = updateRecipe($recipeId, $recipeName, $description, $servings, $preparationTime);
    
    if ($success) {
      // Clear all existing ingredients first
      $sqlClear = "DELETE FROM recipe_ingredients WHERE recipe_id = ?";
      $stmtClear = $conn->prepare($sqlClear);
      $stmtClear->bind_param("i", $recipeId);
      $stmtClear->execute();
      $stmtClear->close();
      
      // Add new ingredients
      if (isset($_POST['ingredient_id']) && is_array($_POST['ingredient_id'])) {
        $ingredient_ids = $_POST['ingredient_id'];
        $quantities = $_POST['quantity'];
        
        for ($i = 0; $i < count($ingredient_ids); $i++) {
          $ingredientId = intval($ingredient_ids[$i]);
          $quantity = floatval($quantities[$i]);
          
          if ($ingredientId > 0 && $quantity > 0) {
            addIngredientToRecipe($recipeId, $ingredientId, $quantity);
          }
        }
      }
      
      $_SESSION['message'] = "Recipe updated successfully";
      $_SESSION['message_type'] = "success";
      header("Location: view_recipe.php?id=$recipeId");
      exit();
    } else {
      $_SESSION['message'] = "Error updating recipe";
      $_SESSION['message_type'] = "error";
    }
  }
}
?>

<div class="container">
  <h1>Edit Recipe</h1>
  
  <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"] . "?id=$recipeId"); ?>">
    <div class="form-group">
      <label for="recipe_name">Recipe Name *</label>
      <input type="text" id="recipe_name" name="recipe_name" required value="<?php echo htmlspecialchars($recipe['recipe_name']); ?>">
    </div>
    
    <div class="form-group">
      <label for="description">Description</label>
      <textarea id="description" name="description" rows="3"><?php echo htmlspecialchars($recipe['description']); ?></textarea>
    </div>
    
    <div class="form-group">
      <label for="servings">Number of Servings *</label>
      <input type="number" id="servings" name="servings" min="1" required value="<?php echo $recipe['servings']; ?>">
    </div>
    
    <div class="form-group">
      <label for="preparation_time">Preparation Time (minutes)</label>
      <input type="number" id="preparation_time" name="preparation_time" min="0" value="<?php echo $recipe['preparation_time']; ?>">
    </div>
    
    <h2>Ingredients</h2>
    <p>Edit ingredients for your recipe:</p>
    
    <div class="ingredients-container">
      <?php if(count($recipeIngredients) > 0): ?>
        <?php foreach($recipeIngredients as $ingredient): ?>
          <div class="ingredient-row">
            <div>
              <select name="ingredient_id[]" class="ingredient-select" required>
                <option value="">Select an ingredient</option>
                <?php foreach ($allIngredients as $ing): ?>
                  <option value="<?php echo $ing['ingredient_id']; ?>" 
                          data-cost="<?php echo $ing['cost_per_unit']; ?>"
                          data-unit="<?php echo $ing['unit']; ?>"
                          <?php echo ($ing['ingredient_id'] == $ingredient['ingredient_id']) ? 'selected' : ''; ?>>
                    <?php echo $ing['ingredient_name']; ?> 
                    ($<?php echo number_format($ing['cost_per_unit'], 2); ?>/<?php echo $ing['unit']; ?>)
                  </option>
                <?php endforeach; ?>
              </select>
            </div>
            <div>
              <input type="number" name="quantity[]" class="quantity" min="0.01" step="0.01" 
                     value="<?php echo $ingredient['quantity']; ?>" required>
            </div>
            <div>
              <span class="unit"><?php echo $ingredient['unit']; ?></span>
            </div>
            <div>
              <span class="remove-ingredient">✕</span>
            </div>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
        <div class="ingredient-row">
          <div>
            <select name="ingredient_id[]" class="ingredient-select" required>
              <option value="">Select an ingredient</option>
              <?php foreach ($allIngredients as $ing): ?>
                <option value="<?php echo $ing['ingredient_id']; ?>" 
                        data-cost="<?php echo $ing['cost_per_unit']; ?>"
                        data-unit="<?php echo $ing['unit']; ?>">
                  <?php echo $ing['ingredient_name']; ?> 
                  ($<?php echo number_format($ing['cost_per_unit'], 2); ?>/<?php echo $ing['unit']; ?>)
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div>
            <input type="number" name="quantity[]" class="quantity" min="0.01" step="0.01" value="1" required>
          </div>
          <div>
            <span class="unit"></span>
          </div>
          <div>
            <span class="remove-ingredient">✕</span>
          </div>
        </div>
      <?php endif; ?>
    </div>
    
    <button type="button" id="add-ingredient" class="btn">Add Another Ingredient</button>
    
    <div class="form-group" style="margin-top: 2rem;">
      <button type="submit" class="btn">Update Recipe</button>
      <a href="view_recipe.php?id=<?php echo $recipeId; ?>" class="btn" style="background-color: var(--dark-grey);">Cancel</a>
    </div>
  </form>
  
  <!-- Template for new ingredient rows -->
  <template id="ingredient-template">
    <div class="ingredient-row">
      <div>
        <select name="ingredient_id[]" class="ingredient-select" required>
          <option value="">Select an ingredient</option>
          <?php foreach ($allIngredients as $ing): ?>
            <option value="<?php echo $ing['ingredient_id']; ?>" 
                    data-cost="<?php echo $ing['cost_per_unit']; ?>"
                    data-unit="<?php echo $ing['unit']; ?>">
              <?php echo $ing['ingredient_name']; ?> 
              ($<?php echo number_format($ing['cost_per_unit'], 2); ?>/<?php echo $ing['unit']; ?>)
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <input type="number" name="quantity[]" class="quantity" min="0.01" step="0.01" value="1" required>
      </div>
      <div>
        <span class="unit"></span>
      </div>
      <div>
        <span class="remove-ingredient">✕</span>
      </div>
    </div>
  </template>
</div>

<script>
  // Additional JavaScript for this page
  document.addEventListener('DOMContentLoaded', function() {
    // Update unit when ingredient is selected
    document.querySelectorAll('.ingredient-select').forEach(select => {
      select.addEventListener('change', function() {
        const selectedOption = this.options[this.selectedIndex];
        const unitSpan = this.closest('.ingredient-row').querySelector('.unit');
        
        if (selectedOption.dataset.unit) {
          unitSpan.textContent = selectedOption.dataset.unit;
        } else {
          unitSpan.textContent = '';
        }
      });
    });
    
    // Initialize units for pre-selected ingredients
    document.querySelectorAll('.ingredient-select').forEach(select => {
      const selectedOption = select.options[select.selectedIndex];
      const unitSpan = select.closest('.ingredient-row').querySelector('.unit');
      
      if (selectedOption && selectedOption.dataset.unit) {
        unitSpan.textContent = selectedOption.dataset.unit;
      }
    });
  });
</script>

<?php
$conn->close();
include '../includes/footer.php';
?>