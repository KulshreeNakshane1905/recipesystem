<?php
include '../config/db_connect.php';

// Initialize response message
$response = array(
    'success' => false,
    'message' => ''
);

// Check if ingredient ID is provided
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $ingredient_id = $_GET['id'];
    $conn = connectDB();
    
    // First check if ingredient is used in any recipes
    $check_sql = "SELECT COUNT(*) as recipe_count FROM recipe_ingredients WHERE ingredient_id = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("i", $ingredient_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    $row = $check_result->fetch_assoc();
    
    if ($row['recipe_count'] > 0) {
        // Ingredient is used in recipes, cannot delete
        $response['message'] = "Cannot delete this ingredient because it's used in one or more recipes. Please remove it from all recipes first.";
    } else {
        // Ingredient is not used, proceed with deletion
        $sql = "DELETE FROM ingredients WHERE ingredient_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $ingredient_id);
        
        if ($stmt->execute()) {
            $response['success'] = true;
            $response['message'] = "Ingredient deleted successfully!";
        } else {
            $response['message'] = "Error deleting ingredient: " . $conn->error;
        }
        
        $stmt->close();
    }
    
    $check_stmt->close();
    $conn->close();
} else {
    $response['message'] = "Invalid ingredient ID!";
}

// Redirect back to ingredients list with message
session_start();
$_SESSION['message'] = $response['message'];
$_SESSION['message_type'] = $response['success'] ? 'success' : 'error';
header("Location: view_ingredients.php");
exit();
?>