<?php
// recipes/recipe_functions.php

// Get recipe by ID
function getRecipeById($recipeId) {
  $conn = connectDB();
  
  $sql = "SELECT * FROM recipes WHERE recipe_id = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("i", $recipeId);
  $stmt->execute();
  $result = $stmt->get_result();
  
  if ($result->num_rows > 0) {
    $recipe = $result->fetch_assoc();
  } else {
    $recipe = null;
  }
  
  $stmt->close();
  $conn->close();
  
  return $recipe;
}

// Get recipe ingredients
function getRecipeIngredients($recipeId) {
  $conn = connectDB();
  
  $sql = "SELECT ri.*, i.ingredient_name, i.cost_per_unit, i.unit 
          FROM recipe_ingredients ri 
          JOIN ingredients i ON ri.ingredient_id = i.ingredient_id 
          WHERE ri.recipe_id = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("i", $recipeId);
  $stmt->execute();
  $result = $stmt->get_result();
  
  $ingredients = [];
  while ($row = $result->fetch_assoc()) {
    $ingredients[] = $row;
  }
  
  $stmt->close();
  $conn->close();
  
  return $ingredients;
}

// Add recipe
function addRecipe($recipeName, $description, $servings, $preparationTime) {
  $conn = connectDB();
  
  $sql = "INSERT INTO recipes (recipe_name, description, servings, preparation_time) VALUES (?, ?, ?, ?)";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("ssii", $recipeName, $description, $servings, $preparationTime);
  $success = $stmt->execute();
  
  $recipeId = $success ? $conn->insert_id : 0;
  
  $stmt->close();
  $conn->close();
  
  return $recipeId;
}

// Update recipe
function updateRecipe($recipeId, $recipeName, $description, $servings, $preparationTime) {
  $conn = connectDB();
  
  $sql = "UPDATE recipes SET recipe_name = ?, description = ?, servings = ?, preparation_time = ? WHERE recipe_id = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("ssiii", $recipeName, $description, $servings, $preparationTime, $recipeId);
  $success = $stmt->execute();
  
  $stmt->close();
  $conn->close();
  
  return $success;
}

// Delete recipe
function deleteRecipe($recipeId) {
  $conn = connectDB();
  
  $sql = "DELETE FROM recipes WHERE recipe_id = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("i", $recipeId);
  $success = $stmt->execute();
  
  $stmt->close();
  $conn->close();
  
  return $success;
}

// Add ingredient to recipe
function addIngredientToRecipe($recipeId, $ingredientId, $quantity) {
  $conn = connectDB();
  
  // Check if this ingredient is already in the recipe
  $sql = "SELECT * FROM recipe_ingredients WHERE recipe_id = ? AND ingredient_id = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("ii", $recipeId, $ingredientId);
  $stmt->execute();
  $result = $stmt->get_result();
  
  if ($result->num_rows > 0) {
    // Update existing quantity
    $sql = "UPDATE recipe_ingredients SET quantity = ? WHERE recipe_id = ? AND ingredient_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("dii", $quantity, $recipeId, $ingredientId);
  } else {
    // Insert new ingredient
    $sql = "INSERT INTO recipe_ingredients (recipe_id, ingredient_id, quantity) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iid", $recipeId, $ingredientId, $quantity);
  }
  
  $success = $stmt->execute();
  
  $stmt->close();
  $conn->close();
  
  return $success;
}

// Remove ingredient from recipe
function removeIngredientFromRecipe($recipeId, $ingredientId) {
  $conn = connectDB();
  
  $sql = "DELETE FROM recipe_ingredients WHERE recipe_id = ? AND ingredient_id = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("ii", $recipeId, $ingredientId);
  $success = $stmt->execute();
  
  $stmt->close();
  $conn->close();
  
  return $success;
}

// Calculate recipe costs
function calculateRecipeCost($recipeId) {
  $conn = connectDB();
  $totalCost = 0;
  
  $sql = "SELECT ri.quantity, i.cost_per_unit 
          FROM recipe_ingredients ri 
          JOIN ingredients i ON ri.ingredient_id = i.ingredient_id 
          WHERE ri.recipe_id = ?";
          
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("i", $recipeId);
  $stmt->execute();
  $result = $stmt->get_result();
  
  while($row = $result->fetch_assoc()) {
    $totalCost += $row['quantity'] * $row['cost_per_unit'];
  }
  
  $stmt->close();
  $conn->close();
  
  return $totalCost;
}

function calculateCostPerServing($recipeId) {
  $recipe = getRecipeById($recipeId);
  $totalCost = calculateRecipeCost($recipeId);
  
  $costPerServing = $recipe['servings'] > 0 ? $totalCost / $recipe['servings'] : $totalCost;
  
  return $costPerServing;
}

// Calculate ingredient cost percentage
function calculateIngredientCostPercentage($recipeId, $ingredientId, $quantity, $costPerUnit) {
  $totalCost = calculateRecipeCost($recipeId);
  $ingredientCost = $quantity * $costPerUnit;
  
  $percentage = $totalCost > 0 ? ($ingredientCost / $totalCost) * 100 : 0;
  
  return $percentage;
}
?>