// js/script.js
document.addEventListener('DOMContentLoaded', function() {
    // Dynamic ingredient addition for recipe form
    const addIngredientBtn = document.getElementById('add-ingredient');
    if (addIngredientBtn) {
      addIngredientBtn.addEventListener('click', addIngredientRow);
    }
    
    // Set up event listeners for existing ingredient rows
    setupIngredientRowListeners();
    
    // Calculate initial costs if on view recipe page
    calculateAllCosts();
  });
  
  // Function to add a new ingredient row to the form
  function addIngredientRow() {
    const ingredientsContainer = document.querySelector('.ingredients-container');
    const ingredientTemplate = document.getElementById('ingredient-template');
    
    if (ingredientsContainer && ingredientTemplate) {
      const newRow = ingredientTemplate.content.cloneNode(true);
      ingredientsContainer.appendChild(newRow);
      
      // Set up listeners for the new row
      setupIngredientRowListeners();
    }
  }
  
  // Set up event listeners for ingredient rows
  function setupIngredientRowListeners() {
    // Add event listeners to quantity inputs
    const quantityInputs = document.querySelectorAll('.ingredient-row .quantity');
    quantityInputs.forEach(input => {
      input.addEventListener('input', function() {
        calculateIngredientCost(this.closest('.ingredient-row'));
        calculateTotalCost();
      });
    });
    
    // Add event listeners to ingredient selects
    const ingredientSelects = document.querySelectorAll('.ingredient-row .ingredient-select');
    ingredientSelects.forEach(select => {
      select.addEventListener('change', function() {
        calculateIngredientCost(this.closest('.ingredient-row'));
        calculateTotalCost();
      });
    });
    
    // Add event listeners to remove buttons
    const removeButtons = document.querySelectorAll('.remove-ingredient');
    removeButtons.forEach(button => {
      button.addEventListener('click', function() {
        this.closest('.ingredient-row').remove();
        calculateTotalCost();
      });
    });
  }
  
  // Calculate cost for a single ingredient row
  function calculateIngredientCost(row) {
    if (!row) return;
    
    const quantityInput = row.querySelector('.quantity');
    const costPerUnitSpan = row.querySelector('.cost-per-unit');
    const totalCostSpan = row.querySelector('.total-cost');
    
    if (quantityInput && costPerUnitSpan && totalCostSpan) {
      const quantity = parseFloat(quantityInput.value) || 0;
      const costPerUnit = parseFloat(costPerUnitSpan.dataset.cost) || 0;
      const totalCost = quantity * costPerUnit;
      
      totalCostSpan.textContent = totalCost.toFixed(2);
      totalCostSpan.dataset.cost = totalCost;
    }
  }
  
  // Calculate total cost of all ingredients
  function calculateTotalCost() {
    const totalCostElements = document.querySelectorAll('.total-cost');
    const totalCostDisplay = document.getElementById('total-cost');
    const costPerServingDisplay = document.getElementById('cost-per-serving');
    const servingsInput = document.getElementById('servings');
    
    if (totalCostElements.length && totalCostDisplay) {
      let totalCost = 0;
      
      totalCostElements.forEach(element => {
        totalCost += parseFloat(element.dataset.cost) || 0;
      });
      
      totalCostDisplay.textContent = totalCost.toFixed(2);
      
      // Calculate cost per serving if applicable
      if (costPerServingDisplay && servingsInput) {
        const servings = parseInt(servingsInput.value) || 1;
        const costPerServing = totalCost / servings;
        costPerServingDisplay.textContent = costPerServing.toFixed(2);
      }
      
      // Update ingredient percentages
      updateIngredientPercentages(totalCost);
    }
  }
  
  // Update percentage breakdown of ingredients
  function updateIngredientPercentages(totalCost) {
    if (!totalCost) return;
    
    const percentageElements = document.querySelectorAll('.cost-percentage');
    
    percentageElements.forEach(element => {
      const cost = parseFloat(element.dataset.cost) || 0;
      const percentage = (cost / totalCost) * 100;
      element.textContent = percentage.toFixed(1) + '%';
    });
  }
  
  // Calculate all costs (for initial page load)
  function calculateAllCosts() {
    const ingredientRows = document.querySelectorAll('.ingredient-row');
    
    ingredientRows.forEach(row => {
      calculateIngredientCost(row);
    });
    
    calculateTotalCost();
  }