<?php
/**
 * Ingredient management functions for Recipe Cost Calculator
 */

/**
 * Get all ingredients from the database
 * 
 * @param mysqli $conn Database connection
 * @param string $sort Field to sort by
 * @param string $order Sort order (ASC or DESC)
 * @param string $search Optional search term for filtering
 * @return array Array of ingredients
 */
function getAllIngredients($conn, $sort = 'ingredient_name', $order = 'ASC', $search = '') {
    $ingredients = [];
    
    // Validate sort field to prevent SQL injection
    $valid_sort_fields = ['ingredient_id', 'ingredient_name', 'cost_per_unit', 'unit', 'created_at', 'updated_at'];
    if (!in_array($sort, $valid_sort_fields)) {
        $sort = 'ingredient_name';
    }
    
    // Validate order
    $order = strtoupper($order) === 'DESC' ? 'DESC' : 'ASC';
    
    // Prepare query with or without search
    if (!empty($search)) {
        $sql = "SELECT * FROM ingredients WHERE ingredient_name LIKE ? ORDER BY $sort $order";
        $stmt = $conn->prepare($sql);
        $search_param = "%$search%";
        $stmt->bind_param("s", $search_param);
    } else {
        $sql = "SELECT * FROM ingredients ORDER BY $sort $order";
        $stmt = $conn->prepare($sql);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $ingredients[] = $row;
    }
    
    $stmt->close();
    return $ingredients;
}

/**
 * Get a single ingredient by ID
 * 
 * @param mysqli $conn Database connection
 * @param int $ingredient_id The ID of the ingredient to retrieve
 * @return array|bool The ingredient data or false if not found
 */
function getIngredientById($conn, $ingredient_id) {
    $sql = "SELECT * FROM ingredients WHERE ingredient_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $ingredient_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $ingredient = $result->fetch_assoc();
        $stmt->close();
        return $ingredient;
    }
    
    $stmt->close();
    return false;
}

/**
 * Add a new ingredient to the database
 * 
 * @param mysqli $conn Database connection
 * @param string $name Ingredient name
 * @param float $cost_per_unit Cost per unit
 * @param string $unit Unit of measurement
 * @return array Result with success status and message
 */
function addIngredient($conn, $name, $cost_per_unit, $unit) {
    $result = [
        'success' => false,
        'message' => ''
    ];
    
    // Check if ingredient already exists
    $check_sql = "SELECT ingredient_id FROM ingredients WHERE ingredient_name = ? AND unit = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("ss", $name, $unit);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows > 0) {
        $result['message'] = "An ingredient with this name and unit already exists!";
        $check_stmt->close();
        return $result;
    }
    
    $check_stmt->close();
    
    // Insert new ingredient
    $sql = "INSERT INTO ingredients (ingredient_name, cost_per_unit, unit) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sds", $name, $cost_per_unit, $unit);
    
    if ($stmt->execute()) {
        $result['success'] = true;
        $result['message'] = "Ingredient added successfully!";
        $result['ingredient_id'] = $stmt->insert_id;
    } else {
        $result['message'] = "Error adding ingredient: " . $conn->error;
    }
    
    $stmt->close();
    return $result;
}

/**
 * Update an existing ingredient
 * 
 * @param mysqli $conn Database connection
 * @param int $ingredient_id Ingredient ID
 * @param string $name Updated name
 * @param float $cost_per_unit Updated cost per unit
 * @param string $unit Updated unit
 * @return array Result with success status and message
 */
function updateIngredient($conn, $ingredient_id, $name, $cost_per_unit, $unit) {
    $result = [
        'success' => false,
        'message' => ''
    ];
    
    // Check if ingredient exists
    $check_sql = "SELECT ingredient_id FROM ingredients WHERE ingredient_id = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("i", $ingredient_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows === 0) {
        $result['message'] = "Ingredient not found!";
        $check_stmt->close();
        return $result;
    }
    
    $check_stmt->close();
    
    // Update ingredient
    $sql = "UPDATE ingredients SET ingredient_name = ?, cost_per_unit = ?, unit = ? WHERE ingredient_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sdsi", $name, $cost_per_unit, $unit, $ingredient_id);
    
    if ($stmt->execute()) {
        $result['success'] = true;
        $result['message'] = "Ingredient updated successfully!";
    } else {
        $result['message'] = "Error updating ingredient: " . $conn->error;
    }
    
    $stmt->close();
    return $result;
}

/**
 * Delete an ingredient from the database
 * 
 * @param mysqli $conn Database connection
 * @param int $ingredient_id Ingredient ID to delete
 * @return array Result with success status and message
 */
function deleteIngredient($conn, $ingredient_id) {
    $result = [
        'success' => false,
        'message' => ''
    ];
    
    // First check if ingredient is used in any recipes
    $check_sql = "SELECT COUNT(*) as recipe_count FROM recipe_ingredients WHERE ingredient_id = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("i", $ingredient_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    $row = $check_result->fetch_assoc();
    
    if ($row['recipe_count'] > 0) {
        $result['message'] = "Cannot delete this ingredient because it's used in one or more recipes. Please remove it from all recipes first.";
        $check_stmt->close();
        return $result;
    }
    
    $check_stmt->close();
    
    // Delete the ingredient
    $sql = "DELETE FROM ingredients WHERE ingredient_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $ingredient_id);
    
    if ($stmt->execute()) {
        $result['success'] = true;
        $result['message'] = "Ingredient deleted successfully!";
    } else {
        $result['message'] = "Error deleting ingredient: " . $conn->error;
    }
    
    $stmt->close();
    return $result;
}

/**
 * Check if an ingredient is used in any recipes
 * 
 * @param mysqli $conn Database connection
 * @param int $ingredient_id The ingredient ID to check
 * @return bool True if ingredient is used in recipes, false otherwise
 */
function isIngredientUsedInRecipes($conn, $ingredient_id) {
    $sql = "SELECT COUNT(*) as count FROM recipe_ingredients WHERE ingredient_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $ingredient_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    
    $stmt->close();
    return ($row['count'] > 0);
}

/**
 * Get recipes using a specific ingredient
 * 
 * @param mysqli $conn Database connection
 * @param int $ingredient_id The ingredient ID
 * @return array Array of recipes using this ingredient
 */
function getRecipesUsingIngredient($conn, $ingredient_id) {
    $recipes = [];
    
    $sql = "SELECT r.recipe_id, r.recipe_name 
            FROM recipes r
            JOIN recipe_ingredients ri ON r.recipe_id = ri.recipe_id
            WHERE ri.ingredient_id = ?
            ORDER BY r.recipe_name";
            
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $ingredient_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $recipes[] = $row;
    }
    
    $stmt->close();
    return $recipes;
}
?>