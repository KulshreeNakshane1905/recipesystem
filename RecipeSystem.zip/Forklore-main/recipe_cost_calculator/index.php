<?php
// index.php
include 'config/db_connect.php';
include 'includes/header.php';

$conn = connectDB();
$sql = "SELECT * FROM recipes ORDER BY recipe_name";
$result = $conn->query($sql);

// Calculate recipe costs
function calculateRecipeCost($recipeId) {
  $conn = connectDB();
  $totalCost = 0;
  
  $sql = "SELECT ri.quantity, i.cost_per_unit 
          FROM recipe_ingredients ri 
          JOIN ingredients i ON ri.ingredient_id = i.ingredient_id 
          WHERE ri.recipe_id = ?";
          
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("i", $recipeId);
  $stmt->execute();
  $result = $stmt->get_result();
  
  while($row = $result->fetch_assoc()) {
    $totalCost += $row['quantity'] * $row['cost_per_unit'];
  }
  
  $stmt->close();
  
  return $totalCost;
}

function calculateCostPerServing($recipeId) {
  $conn = connectDB();
  $totalCost = calculateRecipeCost($recipeId);
  
  $sql = "SELECT servings FROM recipes WHERE recipe_id = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("i", $recipeId);
  $stmt->execute();
  $result = $stmt->get_result();
  $recipe = $result->fetch_assoc();
  
  $costPerServing = $recipe['servings'] > 0 ? $totalCost / $recipe['servings'] : $totalCost;
  
  $stmt->close();
  
  return $costPerServing;
}
?>

<div class="container">
  <h1>Recipe Cost Calculator</h1>
  
  <div class="recipe-list">
    <h2>Your Recipes</h2>
    <a href="recipes/add_recipe.php" class="btn">Add New Recipe</a>
    
    <div class="table-container">
      <table class="recipe-table">
        <thead>
          <tr>
            <th>Recipe Name</th>
            <th>Servings</th>
            <th>Total Cost</th>
            <th>Cost Per Serving</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php if($result->num_rows > 0): ?>
            <?php while($recipe = $result->fetch_assoc()): ?>
              <tr>
                <td><?php echo htmlspecialchars($recipe['recipe_name']); ?></td>
                <td><?php echo $recipe['servings']; ?></td>
                <td>$<?php echo number_format(calculateRecipeCost($recipe['recipe_id']), 2); ?></td>
                <td>$<?php echo number_format(calculateCostPerServing($recipe['recipe_id']), 2); ?></td>
                <td>
                  <a href="recipes/view_recipe.php?id=<?php echo $recipe['recipe_id']; ?>" class="btn btn-sm">View</a>
                  <a href="recipes/edit_recipe.php?id=<?php echo $recipe['recipe_id']; ?>" class="btn btn-sm">Edit</a>
                  <a href="recipes/delete_recipe.php?id=<?php echo $recipe['recipe_id']; ?>" 
                    class="btn btn-sm btn-danger"
                    onclick="return confirm('Are you sure you want to delete this recipe?')">Delete</a>
                </td>
              </tr>
            <?php endwhile; ?>
          <?php else: ?>
            <tr>
              <td colspan="5">No recipes found. Add your first recipe!</td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php
$conn->close();
include 'includes/footer.php';
?>