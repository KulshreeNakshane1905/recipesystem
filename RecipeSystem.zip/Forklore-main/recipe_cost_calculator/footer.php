<?php
// config/db_connect.php
function connectDB() {
  $servername = "localhost";
  $username = "username"; // Change to your MySQL username
  $password = "password"; // Change to your MySQL password
  $dbname = "recipe_cost_calculator";

  $conn = new mysqli($servername, $username, $password, $dbname);
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }
  return $conn;
}
?>