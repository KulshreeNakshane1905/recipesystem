<?php
// recipes/delete_recipe.php
include '../config/db_connect.php';
include '../includes/header.php';
require_once 'recipe_functions.php';

// Check if ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
  $_SESSION['message'] = "Invalid recipe ID";
  $_SESSION['message_type'] = "error";
  header("Location: ../index.php");
  exit();
}

$recipeId = intval($_GET['id']);

// Delete recipe
$success = deleteRecipe($recipeId);

if ($success) {
  $_SESSION['message'] = "Recipe deleted successfully";
  $_SESSION['message_type'] = "success";
} else {
  $_SESSION['message'] = "Error deleting recipe";
  $_SESSION['message_type'] = "error";
}

header("Location: ../index.php");
exit();
?>