<?php
// ingredients/ingredient_functions.php

// Get all ingredients
function getAllIngredients() {
  $conn = connectDB();
  
  $sql = "SELECT * FROM ingredients ORDER BY ingredient_name";
  $result = $conn->query($sql);
  
  $ingredients = [];
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      $ingredients[] = $row;
    }
  }
  
  $conn->close();
  
  return $ingredients;
}

// Get ingredient by ID
function getIngredientById($ingredientId) {
  $conn = connectDB();
  
  $sql = "SELECT * FROM ingredients WHERE ingredient_id = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("i", $ingredientId);
  $stmt->execute();
  $result = $stmt->get_result();
  
  if ($result->num_rows > 0) {
    $ingredient = $result->fetch_assoc();
  } else {
    $ingredient = null;
  }
  
  $stmt->close();
  $conn->close();
  
  return $ingredient;
}

// Add ingredient
function addIngredient($ingredientName, $costPerUnit, $unit) {
  $conn = connectDB();
  
  $sql = "INSERT INTO ingredients (ingredient_name, cost_per_unit, unit) VALUES (?, ?, ?)";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("sds", $ingredientName, $costPerUnit, $unit);
  $success = $stmt->execute();
  
  $ingredientId = $success ? $conn->insert_id : 0;
  
  $stmt->close();
  $conn->close();
  
  return $ingredientId;
}

// Update ingredient
function updateIngredient($ingredientId, $ingredientName, $costPerUnit, $unit) {
  $conn = connectDB();
  
  $sql = "UPDATE ingredients SET ingredient_name = ?, cost_per_unit = ?, unit = ? WHERE ingredient_id = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("sdsi", $ingredientName, $costPerUnit, $unit, $ingredientId);
  $success = $stmt->execute();
  
  $stmt->close();
  $conn->close();
  
  return $success;
}

// Delete ingredient
function deleteIngredient($ingredientId) {
  $conn = connectDB();
  
  // Check if ingredient is used in any recipes
  $sql = "SELECT COUNT(*) as count FROM recipe_ingredients WHERE ingredient_id = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("i", $ingredientId);
  $stmt->execute();
  $result = $stmt->get_result();
  $row = $result->fetch_assoc();
  
  if ($row['count'] > 0) {
    // Ingredient is in use, cannot delete
    $stmt->close();
    $conn->close();
    return false;
  }
  
  // Delete ingredient
  $sql = "DELETE FROM ingredients WHERE ingredient_id = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("i", $ingredientId);
  $success = $stmt->execute();
  
  $stmt->close();
  $conn->close();
  
  return $success;
}

// Check if ingredient is in use
function isIngredientInUse($ingredientId) {
  $conn = connectDB();
  
  $sql = "SELECT COUNT(*) as count FROM recipe_ingredients WHERE ingredient_id = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("i", $ingredientId);
  $stmt->execute();
  $result = $stmt->get_result();
  $row = $result->fetch_assoc();
  
  $inUse = ($row['count'] > 0);
  
  $stmt->close();
  $conn->close();
  
  return $inUse;
}

// Get recipes using ingredient
function getRecipesUsingIngredient($ingredientId) {
  $conn = connectDB();
  
  $sql = "SELECT r.recipe_id, r.recipe_name 
          FROM recipes r 
          JOIN recipe_ingredients ri ON r.recipe_id = ri.recipe_id 
          WHERE ri.ingredient_id = ? 
          ORDER BY r.recipe_name";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("i", $ingredientId);
  $stmt->execute();
  $result = $stmt->get_result();
  
  $recipes = [];
  while ($row = $result->fetch_assoc()) {
    $recipes[] = $row;
  }
  
  $stmt->close();
  $conn->close();
  
  return $recipes;
}
?>