<?php
// ingredients/index.php
include '../config/db_connect.php';
include '../includes/header.php';
require_once 'ingredient_functions.php';

$ingredients = getAllIngredients();
?>

<div class="container">
  <h1>Ingredient Management</h1>
  
  <div class="ingredient-list">
    <h2>Your Ingredients</h2>
    <a href="add_ingredient.php" class="btn">Add New Ingredient</a>
    
    <div class="table-container">
      <table>
        <thead>
          <tr>
            <th>Ingredient Name</th>
            <th>Cost Per Unit</th>
            <th>Unit</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php if(count($ingredients) > 0): ?>
            <?php foreach($ingredients as $ingredient): ?>
              <tr>
                <td><?php echo htmlspecialchars($ingredient['ingredient_name']); ?></td>
                <td>$<?php echo number_format($ingredient['cost_per_unit'], 2); ?></td>
                <td><?php echo htmlspecialchars($ingredient['unit']); ?></td>
                <td>
                  <a href="edit_ingredient.php?id=<?php echo $ingredient['ingredient_id']; ?>" class="btn btn-sm">Edit</a>
                  <a href="delete_ingredient.php?id=<?php echo $ingredient['ingredient_id']; ?>" 
                    class="btn btn-sm btn-danger"
                    onclick="return confirm('Are you sure you want to delete this ingredient?')">Delete</a>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr>
              <td colspan="4">No ingredients found. Add your first ingredient!</td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php include '../includes/footer.php'; ?>