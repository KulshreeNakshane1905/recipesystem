<?php
// ingredients/add_ingredient.php
include '../config/db_connect.php';
include '../includes/header.php';
require_once 'ingredient_functions.php';

// Common measurement units
$commonUnits = ['g', 'kg', 'oz', 'lb', 'ml', 'L', 'tsp', 'tbsp', 'cup', 'piece', 'slice'];

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Sanitize and validate input
  $ingredientName = htmlspecialchars($_POST['ingredient_name']);
  $costPerUnit = floatval($_POST['cost_per_unit']);
  $unit = htmlspecialchars($_POST['unit']);
  
  // Validate ingredient name
  if (empty($ingredientName)) {
    $_SESSION['message'] = "Ingredient name is required";
    $_SESSION['message_type'] = "error";
  } else if ($costPerUnit <= 0) {
    $_SESSION['message'] = "Cost must be greater than zero";
    $_SESSION['message_type'] = "error";
  } else if (empty($unit)) {
    $_SESSION['message'] = "Unit is required";
    $_SESSION['message_type'] = "error";
  } else {
    // Add ingredient to database
    $ingredientId = addIngredient($ingredientName, $costPerUnit, $unit);
    
    if ($ingredientId) {
      $_SESSION['message'] = "Ingredient added successfully";
      $_SESSION['message_type'] = "success";
      header("Location: index.php");
      exit();
    } else {
      $_SESSION['message'] = "Error adding ingredient";
      $_SESSION['message_type'] = "error";
    }
  }
}
?>

<div class="container">
  <h1>Add New Ingredient</h1>
  
  <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <div class="form-group">
      <label for="ingredient_name">Ingredient Name *</label>
      <input type="text" id="ingredient_name" name="ingredient_name" required>
    </div>
    
    <div class="form-group">
      <label for="cost_per_unit">Cost Per Unit *</label>
      <div style="display: flex; align-items: center;">
        <span style="margin-right: 5px;">$</span>
        <input type="number" id="cost_per_unit" name="cost_per_unit" min="0.01" step="0.01" required>
      </div>
    </div>
    
    <div class="form-group">
      <label for="unit">Unit of Measurement *</label>
      <input type="text" id="unit" name="unit" list="common-units" required>
      <datalist id="common-units">
        <?php foreach($commonUnits as $commonUnit): ?>
          <option value="<?php echo $commonUnit; ?>">
        <?php endforeach; ?>
      </datalist>
    </div>
    
    <div class="form-group">
      <button type="submit" class="btn">Save Ingredient</button>
      <a href="index.php" class="btn" style="background-color: var(--dark-grey);">Cancel</a>
    </div>
  </form>
</div>

<?php include '../includes/footer.php'; ?>