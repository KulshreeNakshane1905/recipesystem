<?php
include '../config/db_connect.php';
include '../includes/header.php';

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Display messages if any
$message = '';
$message_type = '';

if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    $message_type = isset($_SESSION['message_type']) ? $_SESSION['message_type'] : 'info';
    unset($_SESSION['message']);
    unset($_SESSION['message_type']);
}

// Connect to database and fetch ingredients
$conn = connectDB();

// Handle sorting
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'ingredient_name';
$order = isset($_GET['order']) && $_GET['order'] == 'desc' ? 'DESC' : 'ASC';

// Toggle sort order for next click
$new_order = ($order == 'ASC') ? 'desc' : 'asc';

// Search functionality
$search = isset($_GET['search']) ? $_GET['search'] : '';
$search_condition = '';
$params = [];
$types = '';

if (!empty($search)) {
    $search_condition = "WHERE ingredient_name LIKE ?";
    $search_param = "%$search%";
    $params[] = $search_param;
    $types .= 's';
}

// Prepare and execute query
$sql = "SELECT * FROM ingredients $search_condition ORDER BY $sort $order";
$stmt = $conn->prepare($sql);

if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();
?>

<div class="container">
    <h1>Ingredient Management</h1>
    
    <?php if (!empty($message)): ?>
        <div class="message <?php echo $message_type; ?>">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>
    
    <div class="actions-bar">
        <a href="add_ingredient.php" class="btn btn-primary">Add New Ingredient</a>
        
        <form method="GET" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="search-form">
            <input type="text" name="search" placeholder="Search ingredients..." value="<?php echo htmlspecialchars($search); ?>">
            <button type="submit" class="btn btn-search">Search</button>
            <?php if (!empty($search)): ?>
                <a href="view_ingredients.php" class="btn btn-clear">Clear</a>
            <?php endif; ?>
        </form>
    </div>
    
    <table class="data-table ingredients-table">
        <thead>
            <tr>
                <th>
                    <a href="?sort=ingredient_name&order=<?php echo $new_order; ?>&search=<?php echo urlencode($search); ?>">
                        Ingredient Name
                        <?php if ($sort == 'ingredient_name'): ?>
                            <span class="sort-icon"><?php echo ($order == 'ASC') ? '↑' : '↓'; ?></span>
                        <?php endif; ?>
                    </a>
                </th>
                <th>
                    <a href="?sort=cost_per_unit&order=<?php echo $new_order; ?>&search=<?php echo urlencode($search); ?>">
                        Cost per Unit
                        <?php if ($sort == 'cost_per_unit'): ?>
                            <span class="sort-icon"><?php echo ($order == 'ASC') ? '↑' : '↓'; ?></span>
                        <?php endif; ?>
                    </a>
                </th>
                <th>
                    <a href="?sort=unit&order=<?php echo $new_order; ?>&search=<?php echo urlencode($search); ?>">
                        Unit
                        <?php if ($sort == 'unit'): ?>
                            <span class="sort-icon"><?php echo ($order == 'ASC') ? '↑' : '↓'; ?></span>
                        <?php endif; ?>
                    </a>
                </th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result->num_rows > 0): ?>
                <?php while ($ingredient = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($ingredient['ingredient_name']); ?></td>
                        <td>$<?php echo number_format($ingredient['cost_per_unit'], 2); ?></td>
                        <td><?php echo htmlspecialchars($ingredient['unit']); ?></td>
                        <td class="actions">
                            <a href="edit_ingredient.php?id=<?php echo $ingredient['ingredient_id']; ?>" class="btn btn-sm btn-edit">Edit</a>
                            <a href="delete_ingredient.php?id=<?php echo $ingredient['ingredient_id']; ?>" 
                               class="btn btn-sm btn-delete"
                               onclick="return confirm('Are you sure you want to delete this ingredient? This cannot be undone.')">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4" class="no-records">No ingredients found. Add your first ingredient!</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    
    <div class="back-link">
        <a href="../index.php" class="btn">Back to Home</a>
    </div>
</div>

<?php
$stmt->close();
$conn->close();
include '../includes/footer.php';
?>